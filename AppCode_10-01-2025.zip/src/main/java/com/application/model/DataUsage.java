package com.application.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DataUsage")
public class DataUsage {

    @Id
    private Long customerId;
    private Double totalDataUsed;
    private Date usageDate;

    public DataUsage() {
        // Default constructor
    }

    public DataUsage(Long customerId, Double totalDataUsed, Date usageDate) {
        this.customerId = customerId;
        this.totalDataUsed = totalDataUsed;
        this.usageDate = usageDate;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Double getTotalDataUsed() {
        return totalDataUsed;
    }

    public void setTotalDataUsed(Double totalDataUsed) {
        this.totalDataUsed = totalDataUsed;
    }

    public Date getUsageDate() {
        return usageDate;
    }

    public void setUsageDate(Date usageDate) {
        this.usageDate = usageDate;
    }

    // Method to handle data retrieval errors gracefully
    public String handleDataRetrievalError() {
        return "An error occurred while retrieving data usage. Please try again later.";
    }

    // Method to display total data usage or "0" if no data is recorded
    public String displayTotalDataUsage() {
        if (totalDataUsed == null || totalDataUsed == 0) {
            return "0";
        }
        return totalDataUsed.toString();
    }
}
