package com.application.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Customer")
public class Customer {

    @Id
    private Long customerId;
    private String customerName;
    private Integer planLimit;

    public Customer() {
    }

    public Customer(Long customerId, String customerName, Integer planLimit) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.planLimit = planLimit;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Integer getPlanLimit() {
        return planLimit;
    }

    public void setPlanLimit(Integer planLimit) {
        this.planLimit = planLimit;
    }
}
