package com.application.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Notifications")
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "NotificationId")
    private Long notificationId;

    @Column(name = "CustomerId", nullable = false)
    private Long customerId;

    @Column(name = "NotificationType", nullable = false)
    private String notificationType;

    @Column(name = "NotificationContent", nullable = false)
    private String notificationContent;

    @Column(name = "SentDate", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date sentDate;

    public Notification() {
    }

    public Notification(Long customerId, String notificationType, String notificationContent, Date sentDate) {
        this.customerId = customerId;
        this.notificationType = notificationType;
        this.notificationContent = notificationContent;
        this.sentDate = sentDate;
    }

    public Long getNotificationId() {
        return notificationId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public String getNotificationContent() {
        return notificationContent;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setNotificationId(Long notificationId) {
        this.notificationId = notificationId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    public void setNotificationContent(String notificationContent) {
        this.notificationContent = notificationContent;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }
}
