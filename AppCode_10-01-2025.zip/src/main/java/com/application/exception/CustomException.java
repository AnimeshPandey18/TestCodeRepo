package com.application.exception;

/**
 * CustomException is a base class for handling exceptions in the application.
 * It provides a centralized way to manage error codes and messages, ensuring
 * that all exceptions are meaningful and provide enough context for debugging.
 */
public class CustomException extends Exception {
    private static final long serialVersionUID = 1L;
    private final String errorCode;
    private final String errorMessage;

    /**
     * Constructs a new CustomException with the specified error code and message.
     *
     * @param errorCode    the error code associated with the exception
     * @param errorMessage the detailed error message
     */
    public CustomException(String errorCode, String errorMessage) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    /**
     * Retrieves the error code associated with this exception.
     *
     * @return the error code
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Retrieves the error message associated with this exception.
     *
     * @return the error message
     */
    public String getErrorMessage() {
        return errorMessage;
    }
}
