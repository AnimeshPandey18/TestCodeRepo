package com.application.service;

import com.application.repository.DataUsageRepository;
import com.application.dto.DataUsageDTO;
import com.application.mapper.DataUsageMapper;
import com.application.entity.DataUsage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class DataUsageService {

    @Autowired
    private DataUsageRepository dataUsageRepository;

    @Autowired
    private DataUsageMapper dataUsageMapper;

    public void initializeDataUsageOperations() {
        // Implement business logic related to data usage operations
        // This could include initializing resources, setting up configurations, etc.
    }

    public DataUsageDTO getDataUsageByCustomerId(Long customerId) {
        try {
            Optional<DataUsage> dataUsageOptional = dataUsageRepository.findDataUsageByCustomerId(customerId);
            if (dataUsageOptional.isPresent()) {
                return dataUsageMapper.toDataUsageDTO(dataUsageOptional.get());
            } else {
                return new DataUsageDTO(); // Return an empty DTO if no data usage is found
            }
        } catch (Exception e) {
            handleDataUsageErrors(e);
            return null; // Return null or handle as per the application's error handling strategy
        }
    }

    public void saveDataUsage(DataUsageDTO dataUsageDTO) {
        try {
            DataUsage dataUsage = dataUsageMapper.toDataUsageEntity(dataUsageDTO);
            dataUsageRepository.saveDataUsage(dataUsage);
        } catch (Exception e) {
            handleDataUsageErrors(e);
        }
    }

    public void handleDataUsageErrors(Exception e) {
        // Handle errors during data usage retrieval and processing
        // This could include logging the error, sending notifications, etc.
        System.err.println("Error occurred: " + e.getMessage());
    }
}
