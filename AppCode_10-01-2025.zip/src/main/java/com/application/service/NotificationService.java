package com.application.service;

import com.application.dto.NotificationDTO;
import com.application.mapper.NotificationMapper;
import com.application.notification.EmailNotificationService;
import com.application.notification.SMSNotificationService;
import com.application.repository.NotificationRepository;
import com.application.repository.NotificationPreferencesRepository;
import com.application.entity.Notification;
import com.application.entity.NotificationPreferences;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private NotificationPreferencesRepository notificationPreferencesRepository;

    @Autowired
    private NotificationMapper notificationMapper;

    @Autowired
    private EmailNotificationService emailNotificationService;

    @Autowired
    private SMSNotificationService smsNotificationService;

    public void initializeNotificationOperations() {
        // Business logic for initializing notification operations
        // This could include setting up scheduled tasks or initializing resources
    }

    @Transactional
    public void sendNotification(NotificationDTO notificationDTO) {
        try {
            Notification notification = notificationMapper.toNotificationEntity(notificationDTO);
            notificationRepository.saveNotification(notification);

            NotificationPreferences preferences = getNotificationPreferences(notificationDTO.getCustomerId());
            if (preferences != null) {
                if ("EMAIL".equalsIgnoreCase(preferences.getPreferredChannel())) {
                    emailNotificationService.sendEmailNotification(notificationDTO);
                } else if ("SMS".equalsIgnoreCase(preferences.getPreferredChannel())) {
                    smsNotificationService.sendSMSNotification(notificationDTO);
                }
            }
        } catch (Exception e) {
            logNotificationError(e);
        }
    }

    public NotificationPreferences getNotificationPreferences(Long customerId) {
        Optional<NotificationPreferences> preferences = notificationPreferencesRepository.findByCustomerId(customerId);
        return preferences.orElse(null);
    }

    public void logNotificationError(Exception e) {
        // Log the error details for further investigation
        // This could involve saving the error details to a database or logging system
    }
}
