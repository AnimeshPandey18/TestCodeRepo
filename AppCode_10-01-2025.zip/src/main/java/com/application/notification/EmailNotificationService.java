package com.application.notification;

import com.application.util.EmailUtil;
import com.application.dto.NotificationDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmailNotificationService {

    @Autowired
    private EmailUtil emailUtil;

    public void sendEmailNotification(NotificationDTO notificationDTO) {
        // Configure the email server settings
        emailUtil.configureEmailServer();

        // Construct the email content
        String subject = "Data Usage Alert";
        String content = buildEmailContent(notificationDTO);

        // Send the email
        emailUtil.sendEmail(notificationDTO.getRecipientEmail(), subject, content);
    }

    private String buildEmailContent(NotificationDTO notificationDTO) {
        StringBuilder contentBuilder = new StringBuilder();
        contentBuilder.append("Dear ").append(notificationDTO.getCustomerName()).append(",\n\n");
        contentBuilder.append("You have exceeded your data plan limit.\n");
        contentBuilder.append("Current Usage: ").append(notificationDTO.getCurrentUsage()).append(" GB\n");
        contentBuilder.append("Plan Limit: ").append(notificationDTO.getPlanLimit()).append(" GB\n");
        contentBuilder.append("Potential Overage Charges: ").append(notificationDTO.getOverageCharges()).append("\n\n");
        contentBuilder.append("Please manage your usage to avoid additional charges.\n");
        contentBuilder.append("Thank you for using our services.\n");
        contentBuilder.append("Best regards,\n");
        contentBuilder.append("Your Service Provider");

        return contentBuilder.toString();
    }
}
