package com.application.notification;

import com.application.util.SMSUtil;
import com.application.dto.NotificationDTO;
import com.application.model.Customer;
import com.application.model.DataUsage;
import com.application.model.NotificationPreferences;
import com.application.repository.CustomerRepository;
import com.application.repository.DataUsageRepository;
import com.application.repository.NotificationPreferencesRepository;
import com.application.repository.ErrorLogsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class SMSNotificationService {

    @Autowired
    private SMSUtil smsUtil;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private DataUsageRepository dataUsageRepository;

    @Autowired
    private NotificationPreferencesRepository notificationPreferencesRepository;

    @Autowired
    private ErrorLogsRepository errorLogsRepository;

    @Transactional
    public void sendSMSNotification(NotificationDTO notificationDTO) {
        try {
            Optional<Customer> customerOpt = customerRepository.findById(notificationDTO.getCustomerId());
            if (customerOpt.isPresent()) {
                Customer customer = customerOpt.get();
                Optional<DataUsage> dataUsageOpt = dataUsageRepository.findByCustomerId(customer.getCustomerId());
                if (dataUsageOpt.isPresent()) {
                    DataUsage dataUsage = dataUsageOpt.get();
                    Optional<NotificationPreferences> preferencesOpt = notificationPreferencesRepository.findByCustomerId(customer.getCustomerId());
                    if (preferencesOpt.isPresent()) {
                        NotificationPreferences preferences = preferencesOpt.get();
                        if ("SMS".equalsIgnoreCase(preferences.getPreferredChannel())) {
                            String message = createNotificationMessage(customer, dataUsage);
                            smsUtil.configureSMSService();
                            smsUtil.sendSMS(customer.getPhoneNumber(), message);
                        }
                    }
                }
            }
        } catch (Exception e) {
            errorLogsRepository.save(new ErrorLog(e.getMessage(), notificationDTO.getCustomerId()));
        }
    }

    private String createNotificationMessage(Customer customer, DataUsage dataUsage) {
        return String.format("Dear %s, you have used %dMB of your %dMB data plan. Please be aware of potential overage charges.",
                customer.getCustomerName(), dataUsage.getTotalDataUsed(), customer.getPlanLimit());
    }
}
