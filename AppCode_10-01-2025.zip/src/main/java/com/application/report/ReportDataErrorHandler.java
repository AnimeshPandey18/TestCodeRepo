package com.application.report;

import com.application.logging.ErrorLogger;
import org.springframework.stereotype.Component;

@Component
public class ReportDataErrorHandler {

    private final ErrorLogger errorLogger;

    public ReportDataErrorHandler(ErrorLogger errorLogger) {
        this.errorLogger = errorLogger;
    }

    /**
     * Handles errors encountered during data processing for reports.
     * Logs the error and provides a meaningful error message.
     *
     * @param e the exception encountered during data processing
     */
    public void handleDataProcessingError(Exception e) {
        // Log the error for further investigation
        errorLogger.logError(e.getMessage(), e);

        // Provide a meaningful error message to the user
        // This could be further enhanced to return a user-friendly message
        System.out.println("An error occurred while processing the report data. Please try again later.");
    }
}
