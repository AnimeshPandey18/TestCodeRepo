package com.application.report;

import com.application.repository.DataUsageRepository;
import com.application.dto.ReportDTO;
import com.application.mapper.ReportMapper;
import com.application.model.Customer;
import com.application.model.DataUsage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DataUsageTrendAnalyzer {

    @Autowired
    private DataUsageRepository dataUsageRepository;

    @Autowired
    private ReportMapper reportMapper;

    public List<ReportDTO> analyzeTrends(List<DataUsage> dataUsages) {
        // Filter data usages for customers exceeding their data limits
        List<DataUsage> exceedingDataUsages = dataUsages.stream()
                .filter(dataUsage -> dataUsage.getTotalDataUsed() > dataUsage.getCustomer().getPlanLimit())
                .collect(Collectors.toList());

        // Map the filtered data usages to ReportDTOs
        return exceedingDataUsages.stream()
                .map(dataUsage -> {
                    Customer customer = dataUsage.getCustomer();
                    return reportMapper.toReportDTO(customer, dataUsage);
                })
                .collect(Collectors.toList());
    }

    public List<ReportDTO> getDataUsageReports(Long customerId) {
        // Retrieve data usage details for a specific customer
        List<DataUsage> dataUsages = dataUsageRepository.findDataUsageByCustomerId(customerId);

        // Analyze trends for the retrieved data usages
        return analyzeTrends(dataUsages);
    }
}
