package com.application.report;

import com.application.service.ReportService;
import com.application.model.Customer;
import com.application.model.DataUsage;
import com.application.model.CustomerDataUsageReport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

@Component
public class ReportDataLogger {

    private static final Logger logger = Logger.getLogger(ReportDataLogger.class.getName());

    @Autowired
    private ReportService reportService;

    @Transactional
    public void logDataProcessing(String logMessage) {
        try {
            logger.log(Level.INFO, "Starting data processing: {0}", logMessage);

            List<Customer> customers = reportService.getAllCustomers();
            for (Customer customer : customers) {
                Optional<DataUsage> dataUsageOpt = reportService.getDataUsageByCustomerId(customer.getCustomerId());
                if (dataUsageOpt.isPresent()) {
                    DataUsage dataUsage = dataUsageOpt.get();
                    if (dataUsage.getTotalDataUsed() > customer.getPlanLimit()) {
                        CustomerDataUsageReport report = new CustomerDataUsageReport();
                        report.setCustomerId(customer.getCustomerId());
                        report.setTotalDataUsage(dataUsage.getTotalDataUsed());
                        reportService.saveCustomerDataUsageReport(report);
                        logger.log(Level.INFO, "Logged data usage for customer: {0}", customer.getCustomerName());
                    }
                } else {
                    logger.log(Level.WARNING, "No data usage found for customer: {0}", customer.getCustomerName());
                }
            }

            logger.log(Level.INFO, "Data processing completed successfully.");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error during data processing: {0}", e.getMessage());
            throw new RuntimeException("Error during data processing", e);
        }
    }
}
