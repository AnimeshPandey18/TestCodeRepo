package com.application.report;

import com.application.util.ReportUtil;
import com.application.model.Report;
import com.application.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.concurrent.CompletableFuture;

@Component
public class ReportExporter {

    @Autowired
    private ReportService reportService;

    @Autowired
    private ReportUtil reportUtil;

    public CompletableFuture<Void> exportReport(Report report, String format) {
        return CompletableFuture.runAsync(() -> {
            try {
                // Retrieve and process data
                Report processedReport = reportService.retrieveAndProcessReportData(report);

                // Format the report data
                String formattedData = reportUtil.formatReportData(processedReport);

                // Export the report data
                reportUtil.exportReportData(processedReport, format);

            } catch (Exception e) {
                // Handle exceptions during report export
                System.err.println("Error exporting report: " + e.getMessage());
            }
        });
    }
}
