package com.application.report;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.application.repository.ErrorLogRepository;
import com.application.model.ErrorLog;
import java.time.LocalDateTime;

@Component
public class ReportLogger {

    private static final Logger logger = LoggerFactory.getLogger(ReportLogger.class);

    @Autowired
    private ErrorLogRepository errorLogRepository;

    /**
     * Logs report generation activities and errors.
     * 
     * @param activityDescription Description of the activity or error to be logged.
     */
    public void logReportActivity(String activityDescription) {
        try {
            // Log the activity description
            logger.info("Report Activity: {}", activityDescription);

            // Create an error log entry
            ErrorLog errorLog = new ErrorLog();
            errorLog.setErrorMessage(activityDescription);
            errorLog.setErrorDate(LocalDateTime.now());

            // Save the error log entry to the database
            errorLogRepository.save(errorLog);
        } catch (Exception e) {
            // Log any exceptions that occur during the logging process
            logger.error("Failed to log report activity: {}", e.getMessage());
        }
    }
}
