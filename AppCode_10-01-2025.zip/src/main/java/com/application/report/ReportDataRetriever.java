package com.application.report;

import com.application.service.ReportService;
import com.application.model.Customer;
import com.application.model.DataUsage;
import com.application.model.CustomerDataUsageReport;
import com.application.repository.CustomerRepository;
import com.application.repository.DataUsageRepository;
import com.application.repository.CustomerDataUsageReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ReportDataRetriever {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private DataUsageRepository dataUsageRepository;

    @Autowired
    private CustomerDataUsageReportRepository customerDataUsageReportRepository;

    /**
     * Retrieves data from the database for report generation based on the given criteria.
     * 
     * @param reportCriteria Criteria for generating the report.
     * @return List of CustomerDataUsageReport containing the report data.
     */
    @Transactional(readOnly = true)
    public List<CustomerDataUsageReport> retrieveDataForReport(String reportCriteria) {
        // Fetch all customers
        List<Customer> customers = customerRepository.findAll();

        // Fetch data usage for each customer
        List<DataUsage> dataUsages = dataUsageRepository.findAll();

        // Process data to generate report
        List<CustomerDataUsageReport> reports = customers.stream()
                .map(customer -> {
                    // Calculate total data used by the customer
                    double totalDataUsed = dataUsages.stream()
                            .filter(dataUsage -> dataUsage.getCustomerId().equals(customer.getCustomerId()))
                            .mapToDouble(DataUsage::getTotalDataUsed)
                            .sum();

                    // Create report entry
                    CustomerDataUsageReport report = new CustomerDataUsageReport();
                    report.setCustomerId(customer.getCustomerId());
                    report.setTotalDataUsage(totalDataUsed);
                    report.setReportDate(java.time.LocalDate.now());

                    return report;
                })
                .collect(Collectors.toList());

        // Save reports to the database
        customerDataUsageReportRepository.saveAll(reports);

        return reports;
    }
}
