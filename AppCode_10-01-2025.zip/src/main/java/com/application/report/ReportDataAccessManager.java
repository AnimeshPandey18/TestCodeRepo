package com.application.report;

import com.application.model.Customer;
import com.application.model.DataUsage;
import com.application.service.ReportService;
import com.application.exception.DataAccessException;
import com.application.repository.CustomerRepository;
import com.application.repository.DataUsageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ReportDataAccessManager {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private DataUsageRepository dataUsageRepository;

    /**
     * Manages data access for report generation, ensuring data security and integrity.
     * This method retrieves customers who have exceeded their data plan limits and
     * prepares a report for Customer Service Representatives.
     *
     * @param user The user requesting the report.
     * @param data The data context for the report.
     * @return A list of report entries containing customer details and data usage.
     * @throws DataAccessException if any issues occur during data retrieval.
     */
    public List<ReportEntry> manageDataAccess(User user, Data data) throws DataAccessException {
        try {
            List<Customer> customers = customerRepository.findAll();
            List<DataUsage> dataUsages = dataUsageRepository.findAll();

            return customers.stream()
                    .map(customer -> {
                        DataUsage usage = dataUsages.stream()
                                .filter(du -> du.getCustomerId().equals(customer.getCustomerId()))
                                .findFirst()
                                .orElse(new DataUsage(customer.getCustomerId(), 0, null));

                        if (usage.getTotalDataUsed() > customer.getPlanLimit()) {
                            return new ReportEntry(
                                    customer.getCustomerId(),
                                    customer.getCustomerName(),
                                    customer.getPlanLimit(),
                                    usage.getTotalDataUsed()
                            );
                        }
                        return null;
                    })
                    .filter(reportEntry -> reportEntry != null)
                    .collect(Collectors.toList());

        } catch (Exception e) {
            throw new DataAccessException("Error retrieving data for report generation", e);
        }
    }

    public static class ReportEntry {
        private String customerId;
        private String customerName;
        private int planLimit;
        private int totalDataUsed;

        public ReportEntry(String customerId, String customerName, int planLimit, int totalDataUsed) {
            this.customerId = customerId;
            this.customerName = customerName;
            this.planLimit = planLimit;
            this.totalDataUsed = totalDataUsed;
        }

        // Getters and setters
    }
}
