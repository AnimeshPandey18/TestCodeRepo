package com.application.report;

import com.application.model.ReportData;
import com.application.service.ReportService;
import com.application.exception.DataRetrievalException;
import com.application.exception.ReportFormattingException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ReportDataFormatter {

    /**
     * Formats the given report data for inclusion in reports.
     * 
     * @param reportData The data to be formatted.
     * @return A formatted string representation of the report data.
     * @throws ReportFormattingException if an error occurs during formatting.
     */
    public String formatDataForReport(ReportData reportData) throws ReportFormattingException {
        try {
            // Validate input data
            if (reportData == null || reportData.getCustomerData() == null) {
                throw new ReportFormattingException("Invalid report data provided.");
            }

            // Format the report data
            List<String> formattedData = reportData.getCustomerData().stream()
                .map(data -> String.format("Customer ID: %s, Name: %s, Plan Limit: %d, Total Data Used: %d",
                        data.getCustomerId(), data.getCustomerName(), data.getPlanLimit(), data.getTotalDataUsed()))
                .collect(Collectors.toList());

            // Join the formatted data into a single string
            return String.join("\n", formattedData);

        } catch (Exception e) {
            throw new ReportFormattingException("Error formatting report data.", e);
        }
    }
}
