package com.application.report;

import com.application.repository.CustomerRepository;
import com.application.repository.DataUsageRepository;
import com.application.dto.ReportDTO;
import com.application.mapper.ReportMapper;
import com.application.model.Customer;
import com.application.model.DataUsage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class CustomerDataUsageReportGenerator {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private DataUsageRepository dataUsageRepository;

    @Autowired
    private ReportMapper reportMapper;

    public List<ReportDTO> generateReport() {
        // Retrieve all customers who have exceeded their data plan limits
        List<Customer> customersExceedingLimit = customerRepository.findAllCustomersExceedingDataLimit();

        // Generate report for each customer
        return customersExceedingLimit.stream().map(customer -> {
            // Retrieve data usage for the customer
            DataUsage dataUsage = dataUsageRepository.findDataUsageByCustomerId(customer.getCustomerId());

            // Map to ReportDTO
            return reportMapper.toReportDTO(customer, dataUsage);
        }).collect(Collectors.toList());
    }
}
