package com.application.report;

import com.application.service.ReportService;
import com.application.model.ReportData;
import com.application.exception.DataRetrievalException;
import com.application.security.AuthorizationService;
import com.application.dto.CustomerDataUsageDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ReportDataExporter {

    @Autowired
    private ReportService reportService;

    @Autowired
    private AuthorizationService authorizationService;

    public void exportData(ReportData reportData, String format) {
        // Check if the user is authorized to access the report
        if (!authorizationService.isAuthorized("CustomerServiceRepresentative")) {
            throw new SecurityException("User not authorized to access this report.");
        }

        try {
            // Retrieve the list of customers who have exceeded their data plan limits
            List<CustomerDataUsageDTO> customerDataUsageList = reportService.getCustomersExceedingDataLimits();

            // Transform the data into the desired format
            String formattedReport = formatReportData(customerDataUsageList, format);

            // Export the formatted report
            exportFormattedData(formattedReport, format);

        } catch (DataRetrievalException e) {
            // Handle data retrieval errors
            System.err.println("Error retrieving data: " + e.getMessage());
            throw new RuntimeException("Failed to retrieve report data.", e);
        }
    }

    private String formatReportData(List<CustomerDataUsageDTO> customerDataUsageList, String format) {
        // Convert the list of customer data usage into the specified format
        // For simplicity, let's assume we are formatting it as a CSV
        return customerDataUsageList.stream()
                .map(dto -> String.join(",", dto.getCustomerId(), dto.getCustomerName(), 
                        String.valueOf(dto.getPlanLimit()), String.valueOf(dto.getTotalDataUsed())))
                .collect(Collectors.joining("\n"));
    }

    private void exportFormattedData(String formattedReport, String format) {
        // Logic to export the formatted data to the specified format
        // This could involve writing to a file, sending over a network, etc.
        // For simplicity, we'll just print it to the console
        System.out.println("Exporting report in format: " + format);
        System.out.println(formattedReport);
    }
}
