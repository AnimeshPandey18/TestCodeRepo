package com.application.report;

import com.application.service.ReportService;
import com.application.model.RawData;
import com.application.model.ReportData;
import com.application.exception.DataProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ReportDataProcessor {

    @Autowired
    private ReportService reportService;

    /**
     * Processes raw data into a format suitable for reporting.
     * This method is expected by ReportService to transform raw data into report data.
     *
     * @param rawData List of raw data to be processed.
     * @return List of processed report data.
     * @throws DataProcessingException if any error occurs during data processing.
     */
    public List<ReportData> processReportData(List<RawData> rawData) throws DataProcessingException {
        try {
            // Transform raw data into report data
            return rawData.stream()
                    .map(data -> new ReportData(
                            data.getCustomerId(),
                            data.getCustomerName(),
                            data.getPlanLimit(),
                            data.getTotalDataUsed()))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            // Handle any exceptions that occur during processing
            throw new DataProcessingException("Error processing report data", e);
        }
    }
}
