package com.application.report;

import com.application.model.Customer;
import com.application.model.DataUsage;
import com.application.model.Report;
import com.application.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ReportFormatter {

    @Autowired
    private ReportService reportService;

    public String formatReportData(Report report) {
        List<Customer> customers = reportService.getCustomersExceedingDataLimits();
        StringBuilder reportBuilder = new StringBuilder();

        reportBuilder.append("Customer Data Usage Report\n");
        reportBuilder.append("--------------------------------------------------\n");
        reportBuilder.append(String.format("%-15s %-20s %-10s %-15s\n", "Customer ID", "Customer Name", "Plan Limit", "Total Data Used"));

        for (Customer customer : customers) {
            DataUsage dataUsage = reportService.getDataUsageByCustomerId(customer.getCustomerId());
            if (dataUsage != null) {
                reportBuilder.append(String.format("%-15s %-20s %-10s %-15s\n",
                        customer.getCustomerId(),
                        customer.getCustomerName(),
                        customer.getPlanLimit(),
                        dataUsage.getTotalDataUsed()));
            } else {
                reportBuilder.append(String.format("%-15s %-20s %-10s %-15s\n",
                        customer.getCustomerId(),
                        customer.getCustomerName(),
                        customer.getPlanLimit(),
                        "Data not available"));
            }
        }

        reportBuilder.append("--------------------------------------------------\n");
        return reportBuilder.toString();
    }
}
