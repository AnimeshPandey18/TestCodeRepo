package com.application.report;

import com.application.service.ReportService;
import com.application.model.Report;
import com.application.dto.ReportDTO;
import com.application.exception.ReportGenerationException;
import com.application.util.ChartUtil;
import com.application.util.ExportUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Component
public class ReportVisualizer {

    @Autowired
    private ReportService reportService;

    public void visualizeReportData(Report report) {
        try {
            // Fetch report data
            List<ReportDTO> reportData = reportService.getReportData(report);

            // Generate visual representations
            CompletableFuture<Void> chartFuture = CompletableFuture.runAsync(() -> {
                ChartUtil.generateCharts(reportData);
            });

            // Export report data
            CompletableFuture<Void> exportFuture = CompletableFuture.runAsync(() -> {
                ExportUtil.exportReport(reportData, "report.csv");
            });

            // Wait for all tasks to complete
            CompletableFuture.allOf(chartFuture, exportFuture).join();

        } catch (Exception e) {
            throw new ReportGenerationException("Error generating report visuals", e);
        }
    }
}
