package com.application.report;

import com.application.model.Customer;
import com.application.model.DataUsage;
import com.application.model.CustomerDataUsageReport;
import com.application.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class ReportFilter {

    @Autowired
    private ReportService reportService;

    public List<CustomerDataUsageReport> applyFilters(List<CustomerDataUsageReport> reports, Map<String, Object> criteria) {
        // Filter reports based on criteria
        return reports.stream()
                .filter(report -> filterByCriteria(report, criteria))
                .collect(Collectors.toList());
    }

    private boolean filterByCriteria(CustomerDataUsageReport report, Map<String, Object> criteria) {
        // Example criteria filtering logic
        if (criteria.containsKey("customerId")) {
            if (!report.getCustomerId().equals(criteria.get("customerId"))) {
                return false;
            }
        }
        if (criteria.containsKey("minDataUsage")) {
            if (report.getTotalDataUsage() < (Integer) criteria.get("minDataUsage")) {
                return false;
            }
        }
        if (criteria.containsKey("maxDataUsage")) {
            if (report.getTotalDataUsage() > (Integer) criteria.get("maxDataUsage")) {
                return false;
            }
        }
        return true;
    }
}
