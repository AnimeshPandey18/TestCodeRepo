package com.application.report;

import com.application.model.ReportData;
import com.application.service.ReportService;
import com.application.exception.ValidationException;
import java.util.List;
import java.util.stream.Collectors;

public class ReportDataValidator {

    /**
     * Validates the report data to ensure accuracy.
     * This method is expected by ReportService to validate the data used in reports.
     *
     * @param reportData The report data to be validated.
     * @throws ValidationException if the report data is invalid.
     */
    public void validateReportData(ReportData reportData) throws ValidationException {
        if (reportData == null) {
            throw new ValidationException("Report data cannot be null.");
        }

        List<String> errors = validateFields(reportData);

        if (!errors.isEmpty()) {
            throw new ValidationException("Report data validation failed: " + String.join(", ", errors));
        }
    }

    /**
     * Validates individual fields of the report data.
     *
     * @param reportData The report data to be validated.
     * @return A list of error messages, if any.
     */
    private List<String> validateFields(ReportData reportData) {
        return reportData.getEntries().stream()
                .flatMap(entry -> {
                    List<String> errors = new ArrayList<>();
                    if (entry.getCustomerId() == null || entry.getCustomerId().isEmpty()) {
                        errors.add("Customer ID is missing.");
                    }
                    if (entry.getCustomerName() == null || entry.getCustomerName().isEmpty()) {
                        errors.add("Customer Name is missing.");
                    }
                    if (entry.getPlanLimit() <= 0) {
                        errors.add("Plan Limit must be greater than zero.");
                    }
                    if (entry.getTotalDataUsed() < 0) {
                        errors.add("Total Data Used cannot be negative.");
                    }
                    return errors.stream();
                })
                .collect(Collectors.toList());
    }
}
