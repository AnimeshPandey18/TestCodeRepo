package com.application.report;

import com.application.model.User;
import com.application.model.Report;
import com.application.service.ReportService;
import com.application.repository.CustomerRepository;
import com.application.repository.DataUsageRepository;
import com.application.exception.UnauthorizedAccessException;
import com.application.exception.ReportNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class ReportAccessManager {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private DataUsageRepository dataUsageRepository;

    @Autowired
    private ReportService reportService;

    /**
     * Manages access to the reports, ensuring only authorized users can view them.
     * 
     * @param user   The user requesting access to the report.
     * @param report The report the user wants to access.
     * @throws UnauthorizedAccessException if the user is not authorized to view the report.
     * @throws ReportNotFoundException     if the report does not exist.
     */
    public void manageReportAccess(User user, Report report) throws UnauthorizedAccessException, ReportNotFoundException {
        if (!isUserAuthorized(user)) {
            throw new UnauthorizedAccessException("User is not authorized to view this report.");
        }

        Optional<Report> reportOptional = reportService.findReportById(report.getReportId());
        if (!reportOptional.isPresent()) {
            throw new ReportNotFoundException("Report not found.");
        }

        displayReport(reportOptional.get());
    }

    /**
     * Checks if the user is authorized to view the report.
     * 
     * @param user The user to check.
     * @return true if the user is authorized, false otherwise.
     */
    private boolean isUserAuthorized(User user) {
        // Logic to check if the user is a Customer Service Representative
        return user.getRoles().contains("CUSTOMER_SERVICE_REPRESENTATIVE");
    }

    /**
     * Displays the report details.
     * 
     * @param report The report to display.
     */
    private void displayReport(Report report) {
        // Logic to display the report details
        List<Object[]> reportData = dataUsageRepository.findExceedingDataUsageCustomers();
        reportData.forEach(data -> {
            System.out.println("Customer ID: " + data[0]);
            System.out.println("Customer Name: " + data[1]);
            System.out.println("Plan Limit: " + data[2]);
            System.out.println("Total Data Used: " + data[3]);
        });
    }
}
