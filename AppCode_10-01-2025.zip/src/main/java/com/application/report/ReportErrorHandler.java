package com.application.report;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.application.logging.ErrorLogger;
import com.application.notification.NotificationService;
import com.application.service.ReportService;

@Component
public class ReportErrorHandler {

    @Autowired
    private ErrorLogger errorLogger;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private ReportService reportService;

    /**
     * Handles errors during report generation and retrieval.
     * Logs the error and notifies the user with a meaningful message.
     *
     * @param e the exception that occurred
     */
    public void handleReportError(Exception e) {
        // Log the error for further investigation
        errorLogger.logError(e.getMessage(), e);

        // Notify the user about the error
        String userMessage = "An error occurred while generating the report. Please try again later.";
        notificationService.notifyUser(userMessage);

        // Additional handling logic if needed
        // For example, retrying the operation or alerting the support team
    }
}
