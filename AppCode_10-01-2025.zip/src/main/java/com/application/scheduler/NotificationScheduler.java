package com.application.scheduler;

import com.application.service.NotificationService;
import com.application.dto.NotificationDTO;
import com.application.model.Customer;
import com.application.model.DataUsage;
import com.application.model.NotificationPreferences;
import com.application.repository.CustomerRepository;
import com.application.repository.DataUsageRepository;
import com.application.repository.NotificationPreferencesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class NotificationScheduler {

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private DataUsageRepository dataUsageRepository;

    @Autowired
    private NotificationPreferencesRepository notificationPreferencesRepository;

    @Scheduled(cron = "0 0 * * * ?") // Runs every hour
    public void scheduleNotificationTasks() {
        List<Customer> customers = customerRepository.findAll();
        for (Customer customer : customers) {
            Optional<DataUsage> dataUsageOpt = dataUsageRepository.findByCustomerId(customer.getCustomerId());
            if (dataUsageOpt.isPresent()) {
                DataUsage dataUsage = dataUsageOpt.get();
                if (shouldNotify(dataUsage, customer.getPlanLimit())) {
                    Optional<NotificationPreferences> preferencesOpt = notificationPreferencesRepository.findByCustomerId(customer.getCustomerId());
                    if (preferencesOpt.isPresent()) {
                        NotificationPreferences preferences = preferencesOpt.get();
                        NotificationDTO notificationDTO = createNotificationDTO(customer, dataUsage, preferences);
                        notificationService.sendNotification(notificationDTO);
                    }
                }
            }
        }
    }

    private boolean shouldNotify(DataUsage dataUsage, double planLimit) {
        double usagePercentage = (dataUsage.getTotalDataUsed() / planLimit) * 100;
        return usagePercentage >= 80;
    }

    private NotificationDTO createNotificationDTO(Customer customer, DataUsage dataUsage, NotificationPreferences preferences) {
        NotificationDTO notificationDTO = new NotificationDTO();
        notificationDTO.setCustomerId(customer.getCustomerId());
        notificationDTO.setCurrentUsage(dataUsage.getTotalDataUsed());
        notificationDTO.setPlanLimit(customer.getPlanLimit());
        notificationDTO.setPreferredChannel(preferences.getPreferredChannel());
        notificationDTO.setNotificationFrequency(preferences.getNotificationFrequency());
        return notificationDTO;
    }
}
