package com.application.scheduler;

import com.application.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ReportScheduler {

    @Autowired
    private ReportService reportService;

    // Schedule the report generation task to run at fixed intervals
    @Scheduled(cron = "0 0 0 * * ?") // This cron expression schedules the task to run daily at midnight
    public void scheduleReportGenerationTasks() {
        try {
            // Fetch necessary data for generating the report
            reportService.fetchReportData();

            // Generate the report for customers exceeding their data limits
            reportService.generateExceedingDataLimitsReport();
        } catch (Exception e) {
            // Handle any errors during report generation and data retrieval
            reportService.handleReportErrors(e);
        }
    }
}
