package com.application.mapper;

import com.application.model.Customer;
import com.application.dto.CustomerDTO;

public class CustomerMapper {

    public CustomerDTO toCustomerDTO(Customer customer) {
        if (customer == null) {
            return null;
        }
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setCustomerId(customer.getCustomerId());
        customerDTO.setCustomerName(customer.getCustomerName());
        customerDTO.setPlanLimit(customer.getPlanLimit());
        // Assuming TotalDataUsed is calculated or retrieved from another source
        // customerDTO.setTotalDataUsed(...);
        return customerDTO;
    }

    public Customer toCustomerEntity(CustomerDTO customerDTO) {
        if (customerDTO == null) {
            return null;
        }
        Customer customer = new Customer();
        customer.setCustomerId(customerDTO.getCustomerId());
        customer.setCustomerName(customerDTO.getCustomerName());
        customer.setPlanLimit(customerDTO.getPlanLimit());
        // Assuming TotalDataUsed is not needed for the entity
        return customer;
    }
}
