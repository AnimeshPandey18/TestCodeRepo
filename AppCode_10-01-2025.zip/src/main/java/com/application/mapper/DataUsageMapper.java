package com.application.mapper;

import com.application.model.DataUsage;
import com.application.dto.DataUsageDTO;

public class DataUsageMapper {

    /**
     * Maps a DataUsage entity to a DataUsageDTO.
     * 
     * @param dataUsage the DataUsage entity to be mapped
     * @return the mapped DataUsageDTO
     */
    public DataUsageDTO toDataUsageDTO(DataUsage dataUsage) {
        if (dataUsage == null) {
            return null;
        }
        
        DataUsageDTO dataUsageDTO = new DataUsageDTO();
        dataUsageDTO.setCustomerId(dataUsage.getCustomerId());
        dataUsageDTO.setTotalDataUsed(dataUsage.getTotalDataUsed());
        dataUsageDTO.setUsageDate(dataUsage.getUsageDate());
        
        return dataUsageDTO;
    }

    /**
     * Maps a DataUsageDTO to a DataUsage entity.
     * 
     * @param dataUsageDTO the DataUsageDTO to be mapped
     * @return the mapped DataUsage entity
     */
    public DataUsage toDataUsageEntity(DataUsageDTO dataUsageDTO) {
        if (dataUsageDTO == null) {
            return null;
        }
        
        DataUsage dataUsage = new DataUsage();
        dataUsage.setCustomerId(dataUsageDTO.getCustomerId());
        dataUsage.setTotalDataUsed(dataUsageDTO.getTotalDataUsed());
        dataUsage.setUsageDate(dataUsageDTO.getUsageDate());
        
        return dataUsage;
    }
}
