package com.application.mapper;

import com.application.model.Notification;
import com.application.dto.NotificationDTO;

public class NotificationMapper {

    public NotificationDTO toNotificationDTO(Notification notification) {
        if (notification == null) {
            return null;
        }
        NotificationDTO notificationDTO = new NotificationDTO();
        notificationDTO.setNotificationId(notification.getNotificationId());
        notificationDTO.setCustomerId(notification.getCustomerId());
        notificationDTO.setNotificationType(notification.getNotificationType());
        notificationDTO.setNotificationContent(notification.getNotificationContent());
        notificationDTO.setSentDate(notification.getSentDate());
        return notificationDTO;
    }

    public Notification toNotificationEntity(NotificationDTO notificationDTO) {
        if (notificationDTO == null) {
            return null;
        }
        Notification notification = new Notification();
        notification.setNotificationId(notificationDTO.getNotificationId());
        notification.setCustomerId(notificationDTO.getCustomerId());
        notification.setNotificationType(notificationDTO.getNotificationType());
        notification.setNotificationContent(notificationDTO.getNotificationContent());
        notification.setSentDate(notificationDTO.getSentDate());
        return notification;
    }
}
