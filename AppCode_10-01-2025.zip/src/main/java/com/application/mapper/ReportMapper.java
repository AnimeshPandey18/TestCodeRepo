package com.application.mapper;

import com.application.dto.ReportDTO;
import com.application.entity.Customer;
import com.application.entity.DataUsage;

public class ReportMapper {

    /**
     * Maps Customer and DataUsage entities to a ReportDTO.
     * This method is used by CustomerDataUsageReportGenerator and DataUsageTrendAnalyzer.
     *
     * @param customer  the Customer entity containing customer details
     * @param dataUsage the DataUsage entity containing data usage details
     * @return a ReportDTO containing the mapped data
     */
    public ReportDTO toReportDTO(Customer customer, DataUsage dataUsage) {
        if (customer == null || dataUsage == null) {
            throw new IllegalArgumentException("Customer and DataUsage cannot be null");
        }

        ReportDTO reportDTO = new ReportDTO();
        reportDTO.setCustomerId(customer.getCustomerId());
        reportDTO.setCustomerName(customer.getCustomerName());
        reportDTO.setPlanLimit(customer.getPlanLimit());
        reportDTO.setTotalDataUsed(dataUsage.getTotalDataUsed());

        return reportDTO;
    }
}
