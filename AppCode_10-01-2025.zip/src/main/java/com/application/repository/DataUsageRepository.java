package com.application.repository;

import com.application.model.DataUsage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DataUsageRepository extends JpaRepository<DataUsage, Long> {

    /**
     * Retrieves data usage details for a specific customer by their ID.
     * This method is expected by multiple components such as DataUsageService,
     * CustomerDataUsageReportGenerator, and DataUsageTrendAnalyzer.
     *
     * @param customerId the ID of the customer whose data usage details are to be retrieved.
     * @return a list of DataUsage records for the specified customer.
     */
    List<DataUsage> findDataUsageByCustomerId(Long customerId);

    /**
     * Saves or updates data usage information in the database.
     * This method is expected by the DataUsageService.
     *
     * @param dataUsage the DataUsage object containing the data usage information to be saved or updated.
     * @return the saved or updated DataUsage object.
     */
    DataUsage saveDataUsage(DataUsage dataUsage);
}
