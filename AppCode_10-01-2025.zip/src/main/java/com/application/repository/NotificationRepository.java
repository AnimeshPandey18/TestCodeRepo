package com.application.repository;

import com.application.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    /**
     * Retrieves notifications for a specific customer by their ID.
     * 
     * @param customerId the ID of the customer
     * @return a list of notifications for the specified customer
     */
    List<Notification> findNotificationsByCustomerId(Long customerId);

    /**
     * Saves or updates notification information in the database.
     * 
     * @param notification the notification to be saved or updated
     * @return the saved or updated notification
     */
    Notification saveNotification(Notification notification);
}
