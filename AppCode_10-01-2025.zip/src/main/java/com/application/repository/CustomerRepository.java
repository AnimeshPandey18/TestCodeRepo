package com.application.repository;

import com.application.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    // Method to retrieve customer details by customer ID
    Customer findCustomerById(Long customerId);

    // Method to retrieve a list of customers who have exceeded their data plan limits
    @Query("SELECT c FROM Customer c JOIN DataUsage d ON c.customerId = d.customerId WHERE d.totalDataUsed > c.planLimit")
    List<Customer> findAllCustomersExceedingDataLimit();
}
