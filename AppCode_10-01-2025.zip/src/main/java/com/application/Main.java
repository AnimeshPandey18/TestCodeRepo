package com.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.application.config.AppConfig;
import com.application.config.DatabaseConfig;
import com.application.config.SchedulerConfig;
import com.application.config.SwaggerConfig;
import com.application.config.MessagingConfig;
import com.application.security.SecurityConfig;
import com.application.service.CustomerService;
import com.application.service.DataUsageService;
import com.application.service.NotificationService;
import com.application.service.ReportService;
import com.application.controller.CustomerController;
import com.application.controller.DataUsageController;
import com.application.controller.NotificationController;
import com.application.controller.ReportController;
import com.application.scheduler.NotificationScheduler;
import com.application.scheduler.ReportScheduler;

@SpringBootApplication
public class Main {

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
        initializeApplication();
    }

    private static void initializeApplication() {
        // Initialize application-wide settings
        AppConfig.initializeAppSettings();

        // Setup database connections
        DatabaseConfig.setupDatabaseConnection();

        // Configure scheduling tasks
        SchedulerConfig.configureSchedulers();

        // Setup Swagger for API documentation
        SwaggerConfig.setupSwagger();

        // Initialize messaging services for notifications
        MessagingConfig.initializeMessagingServices();

        // Secure application endpoints
        SecurityConfig.secureEndpoints();

        // Initialize business logic related to customer operations
        CustomerService.initializeCustomerOperations();

        // Initialize business logic related to data usage operations
        DataUsageService.initializeDataUsageOperations();

        // Initialize business logic related to sending notifications
        NotificationService.initializeNotificationOperations();

        // Initialize business logic related to generating reports
        ReportService.initializeReportOperations();

        // Schedule notification tasks
        NotificationScheduler.scheduleNotificationTasks();

        // Schedule report generation tasks
        ReportScheduler.scheduleReportGenerationTasks();

        // Handle HTTP requests related to customer operations
        CustomerController.handleCustomerRequests();

        // Handle HTTP requests related to data usage operations
        DataUsageController.handleDataUsageRequests();

        // Handle HTTP requests related to notifications
        NotificationController.handleNotificationRequests();

        // Handle HTTP requests related to reports
        ReportController.handleReportRequests();
    }
}
