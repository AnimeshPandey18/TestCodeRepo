package com.application.controller;

import com.application.service.NotificationService;
import com.application.dto.NotificationDTO;
import com.application.model.NotificationPreferences;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @PostMapping("/send")
    public void handleNotificationRequests(@RequestBody NotificationDTO notificationDTO) {
        try {
            // Retrieve customer notification preferences
            NotificationPreferences preferences = notificationService.getNotificationPreferences(notificationDTO.getCustomerId());

            // Check if the customer has exceeded their data plan limit
            if (notificationDTO.getTotalDataUsed() >= notificationDTO.getPlanLimit()) {
                // Send notification based on customer preferences
                notificationService.sendNotification(notificationDTO);
            }
        } catch (Exception e) {
            // Log any errors encountered during the notification process
            notificationService.logNotificationError(e);
        }
    }
}
