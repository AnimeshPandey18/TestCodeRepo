package com.application.controller;

import com.application.service.CustomerService;
import com.application.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/exceeding-data-limits")
    public ResponseEntity<List<Customer>> getCustomersExceedingDataLimits() {
        List<Customer> customers = customerService.retrieveCustomersExceedingDataLimits();
        return ResponseEntity.ok(customers);
    }

    @GetMapping("/data-usage-trends")
    public ResponseEntity<String> getDataUsageTrends() {
        String trends = customerService.analyzeDataUsageTrends();
        return ResponseEntity.ok(trends);
    }

    @PostMapping("/send-notifications")
    public ResponseEntity<String> sendNotifications() {
        List<Customer> customers = customerService.retrieveCustomersExceedingDataLimits();
        customerService.sendNotifications(customers);
        return ResponseEntity.ok("Notifications sent successfully.");
    }

    @GetMapping("/data-usage-monitoring/{customerId}")
    public ResponseEntity<String> monitorDataUsage(@PathVariable Long customerId) {
        String usageDetails = customerService.monitorDataUsage(customerId);
        return ResponseEntity.ok(usageDetails);
    }

    @GetMapping("/data-usage-reports")
    public ResponseEntity<String> generateDataUsageReports() {
        String report = customerService.generateDataUsageReports();
        return ResponseEntity.ok(report);
    }
}
