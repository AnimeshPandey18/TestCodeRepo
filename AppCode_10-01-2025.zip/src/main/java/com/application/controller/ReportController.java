package com.application.controller;

import com.application.service.ReportService;
import com.application.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/exceeding-data-limits")
    public ResponseEntity<?> handleReportRequests() {
        try {
            // Authorize the user
            User currentUser = getCurrentUser();
            if (!reportService.authorizeReportAccess(currentUser)) {
                return ResponseEntity.status(403).body("Access Denied");
            }

            // Fetch report data
            var reportData = reportService.fetchReportData();

            // Generate the report
            var report = reportService.generateExceedingDataLimitsReport();

            return ResponseEntity.ok(report);
        } catch (Exception e) {
            // Handle errors
            reportService.handleReportErrors(e);
            return ResponseEntity.status(500).body("An error occurred while generating the report");
        }
    }

    private User getCurrentUser() {
        // Mock method to get the current user
        // In a real application, this would be replaced with actual user retrieval logic
        return new User("csr", "Customer Service Representative");
    }
}
