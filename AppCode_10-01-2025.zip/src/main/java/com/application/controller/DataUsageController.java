package com.application.controller;

import com.application.service.DataUsageService;
import com.application.model.DataUsage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/data-usage")
public class DataUsageController {

    @Autowired
    private DataUsageService dataUsageService;

    @GetMapping("/{customerId}")
    public ResponseEntity<?> handleDataUsageRequests(@PathVariable Long customerId) {
        try {
            DataUsage dataUsage = dataUsageService.getDataUsageByCustomerId(customerId);
            if (dataUsage == null) {
                return new ResponseEntity<>("0", HttpStatus.OK);
            }
            return new ResponseEntity<>(dataUsage, HttpStatus.OK);
        } catch (Exception e) {
            dataUsageService.handleDataUsageErrors(e);
            return new ResponseEntity<>("An error occurred while retrieving data usage.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/save")
    public ResponseEntity<?> saveDataUsage(@RequestBody DataUsage dataUsage) {
        try {
            dataUsageService.saveDataUsage(dataUsage);
            return new ResponseEntity<>("Data usage saved successfully.", HttpStatus.OK);
        } catch (Exception e) {
            dataUsageService.handleDataUsageErrors(e);
            return new ResponseEntity<>("An error occurred while saving data usage.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
