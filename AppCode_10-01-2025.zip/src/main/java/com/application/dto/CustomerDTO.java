package com.application.dto;

public class CustomerDTO {

    private Long customerId;
    private String customerName;
    private Double planLimit;
    private Double totalDataUsed;

    public CustomerDTO(Long customerId, String customerName, Double planLimit, Double totalDataUsed) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.planLimit = planLimit;
        this.totalDataUsed = totalDataUsed;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public Double getPlanLimit() {
        return planLimit;
    }

    public Double getTotalDataUsed() {
        return totalDataUsed;
    }
}
