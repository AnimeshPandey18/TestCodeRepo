package com.application.dto;

import java.util.Date;

public class DataUsageDTO {

    private String customerId;
    private double totalDataUsed;
    private Date usageDate;

    public DataUsageDTO(String customerId, double totalDataUsed, Date usageDate) {
        this.customerId = customerId;
        this.totalDataUsed = totalDataUsed;
        this.usageDate = usageDate;
    }

    // Method to retrieve the Customer ID
    public String getCustomerId() {
        return customerId;
    }

    // Method to retrieve the total data used
    public double getTotalDataUsed() {
        return totalDataUsed;
    }

    // Method to retrieve the usage date
    public Date getUsageDate() {
        return usageDate;
    }
}
