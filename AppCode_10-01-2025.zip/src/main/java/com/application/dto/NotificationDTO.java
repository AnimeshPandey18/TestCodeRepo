package com.application.dto;

import java.io.Serializable;
import java.util.Date;

public class NotificationDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long notificationId;
    private Long customerId;
    private String notificationType;
    private String notificationContent;
    private Date sentDate;

    public NotificationDTO() {
    }

    public NotificationDTO(Long notificationId, Long customerId, String notificationType, String notificationContent, Date sentDate) {
        this.notificationId = notificationId;
        this.customerId = customerId;
        this.notificationType = notificationType;
        this.notificationContent = notificationContent;
        this.sentDate = sentDate;
    }

    public Long getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(Long notificationId) {
        this.notificationId = notificationId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    public String getNotificationContent() {
        return notificationContent;
    }

    public void setNotificationContent(String notificationContent) {
        this.notificationContent = notificationContent;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }

    @Override
    public String toString() {
        return "NotificationDTO{" +
                "notificationId=" + notificationId +
                ", customerId=" + customerId +
                ", notificationType='" + notificationType + '\'' +
                ", notificationContent='" + notificationContent + '\'' +
                ", sentDate=" + sentDate +
                '}';
    }
}
