package com.application.util;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SMSUtil {

    @Value("${twilio.account.sid}")
    private String accountSid;

    @Value("${twilio.auth.token}")
    private String authToken;

    @Value("${twilio.phone.number}")
    private String fromPhoneNumber;

    /**
     * Configures the SMS service settings for sending messages.
     * This method initializes the Twilio client with the account SID and auth token.
     */
    public void configureSMSService() {
        Twilio.init(accountSid, authToken);
    }

    /**
     * Sends an SMS to the specified recipient with the given message content.
     * 
     * @param recipient The phone number of the recipient.
     * @param message   The message content to be sent.
     */
    public void sendSMS(String recipient, String message) {
        try {
            Message.creator(
                    new PhoneNumber(recipient),
                    new PhoneNumber(fromPhoneNumber),
                    message
            ).create();
        } catch (Exception e) {
            // Log the error for further investigation
            logError(e.getMessage(), recipient);
        }
    }

    /**
     * Logs the error message with the recipient's information for further investigation.
     * 
     * @param errorMessage The error message to be logged.
     * @param recipient    The recipient's phone number associated with the error.
     */
    private void logError(String errorMessage, String recipient) {
        // Implementation for logging the error to the database or a logging service
        // This could involve inserting a record into the ErrorLogs table
    }
}
