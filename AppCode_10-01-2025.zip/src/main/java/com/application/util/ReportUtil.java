package com.application.util;

import com.application.report.Report;
import com.application.report.ReportExporter;
import java.util.List;
import java.util.stream.Collectors;

public class ReportUtil {

    /**
     * Formats the report data for presentation.
     * This method is expected by ReportExporter to format the report data.
     *
     * @param report The report object containing data to be formatted.
     * @return A formatted string representation of the report data.
     */
    public String formatReportData(Report report) {
        StringBuilder formattedData = new StringBuilder();
        formattedData.append("Customer ID, Customer Name, Plan Limit, Total Data Used\n");
        
        report.getData().forEach(data -> {
            formattedData.append(data.getCustomerId()).append(", ")
                         .append(data.getCustomerName()).append(", ")
                         .append(data.getPlanLimit()).append(", ")
                         .append(data.getTotalDataUsed()).append("\n");
        });
        
        return formattedData.toString();
    }

    /**
     * Exports the report data into various formats like CSV and PDF.
     * This method is expected by ReportExporter to handle data export.
     *
     * @param report The report object containing data to be exported.
     * @param format The format in which to export the data (e.g., CSV, PDF).
     * @return A boolean indicating the success of the export operation.
     */
    public boolean exportReportData(Report report, String format) {
        String formattedData = formatReportData(report);
        
        switch (format.toUpperCase()) {
            case "CSV":
                return exportToCSV(formattedData);
            case "PDF":
                return exportToPDF(formattedData);
            default:
                throw new IllegalArgumentException("Unsupported format: " + format);
        }
    }

    /**
     * Exports the formatted data to a CSV file.
     *
     * @param formattedData The formatted data to be exported.
     * @return A boolean indicating the success of the export operation.
     */
    private boolean exportToCSV(String formattedData) {
        // Implement CSV export logic here
        // For example, write the formattedData to a .csv file
        return true;
    }

    /**
     * Exports the formatted data to a PDF file.
     *
     * @param formattedData The formatted data to be exported.
     * @return A boolean indicating the success of the export operation.
     */
    private boolean exportToPDF(String formattedData) {
        // Implement PDF export logic here
        // For example, use a PDF library to create a PDF document from the formattedData
        return true;
    }
}
