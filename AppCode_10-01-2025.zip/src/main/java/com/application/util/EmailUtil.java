package com.application.util;

import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class EmailUtil {

    private Session emailSession;

    public EmailUtil() {
        configureEmailServer();
    }

    private void configureEmailServer() {
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.example.com");
        properties.put("mail.smtp.port", "587");

        Authenticator auth = new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("username@example.com", "password");
            }
        };

        emailSession = Session.getInstance(properties, auth);
    }

    public void sendEmail(String recipient, String subject, String content) {
        try {
            Message message = new MimeMessage(emailSession);
            message.setFrom(new InternetAddress("no-reply@example.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
            message.setSubject(subject);
            message.setText(content);

            Transport.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
            // Log the error for further investigation
        }
    }
}
