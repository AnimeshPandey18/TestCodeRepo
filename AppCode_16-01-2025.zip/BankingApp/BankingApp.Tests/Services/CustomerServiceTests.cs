using System;
using System.Threading.Tasks;
using Xunit;
using Moq;
using BankingApp.Services;
using BankingApp.Models;
using BankingApp.Exceptions;

namespace BankingApp.Tests.Services
{
    public class CustomerServiceTests
    {
        private readonly Mock<ICustomerRepository> _customerRepositoryMock;
        private readonly CustomerService _customerService;

        public CustomerServiceTests()
        {
            _customerRepositoryMock = new Mock<ICustomerRepository>();
            _customerService = new CustomerService(_customerRepositoryMock.Object);
        }

        [Fact]
        public async Task TestCreateCustomer_Success()
        {
            // Arrange
            var newCustomer = new Customer { Id = Guid.NewGuid(), Name = "John Doe", Email = "john.doe@example.com" };
            _customerRepositoryMock.Setup(repo => repo.CreateCustomerAsync(It.IsAny<Customer>()))
                                   .ReturnsAsync(newCustomer);

            // Act
            var result = await _customerService.CreateCustomerAsync(newCustomer);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(newCustomer.Id, result.Id);
            Assert.Equal(newCustomer.Name, result.Name);
            Assert.Equal(newCustomer.Email, result.Email);
        }

        [Fact]
        public async Task TestGetCustomerById_Success()
        {
            // Arrange
            var customerId = Guid.NewGuid();
            var customer = new Customer { Id = customerId, Name = "Jane Doe", Email = "jane.doe@example.com" };
            _customerRepositoryMock.Setup(repo => repo.GetCustomerByIdAsync(customerId))
                                   .ReturnsAsync(customer);

            // Act
            var result = await _customerService.GetCustomerByIdAsync(customerId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(customerId, result.Id);
            Assert.Equal(customer.Name, result.Name);
            Assert.Equal(customer.Email, result.Email);
        }

        [Fact]
        public async Task TestUpdateCustomer_Success()
        {
            // Arrange
            var customerId = Guid.NewGuid();
            var updatedCustomer = new Customer { Id = customerId, Name = "John Smith", Email = "john.smith@example.com" };
            _customerRepositoryMock.Setup(repo => repo.UpdateCustomerAsync(It.IsAny<Customer>()))
                                   .ReturnsAsync(updatedCustomer);

            // Act
            var result = await _customerService.UpdateCustomerAsync(updatedCustomer);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(updatedCustomer.Id, result.Id);
            Assert.Equal(updatedCustomer.Name, result.Name);
            Assert.Equal(updatedCustomer.Email, result.Email);
        }

        [Fact]
        public async Task TestDeleteCustomer_Success()
        {
            // Arrange
            var customerId = Guid.NewGuid();
            _customerRepositoryMock.Setup(repo => repo.DeleteCustomerAsync(customerId))
                                   .Returns(Task.CompletedTask);

            // Act
            await _customerService.DeleteCustomerAsync(customerId);

            // Assert
            _customerRepositoryMock.Verify(repo => repo.DeleteCustomerAsync(customerId), Times.Once);
        }

        [Fact]
        public async Task TestGetCustomerById_NotFound()
        {
            // Arrange
            var customerId = Guid.NewGuid();
            _customerRepositoryMock.Setup(repo => repo.GetCustomerByIdAsync(customerId))
                                   .ReturnsAsync((Customer)null);

            // Act & Assert
            await Assert.ThrowsAsync<CustomerNotFoundException>(() => _customerService.GetCustomerByIdAsync(customerId));
        }

        [Fact]
        public async Task TestUpdateCustomer_NotFound()
        {
            // Arrange
            var customerId = Guid.NewGuid();
            var updatedCustomer = new Customer { Id = customerId, Name = "Non Existent", Email = "non.existent@example.com" };
            _customerRepositoryMock.Setup(repo => repo.UpdateCustomerAsync(It.IsAny<Customer>()))
                                   .ThrowsAsync(new CustomerNotFoundException());

            // Act & Assert
            await Assert.ThrowsAsync<CustomerNotFoundException>(() => _customerService.UpdateCustomerAsync(updatedCustomer));
        }
    }
}
