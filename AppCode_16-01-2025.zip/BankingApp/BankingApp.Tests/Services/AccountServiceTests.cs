using System;
using System.Threading.Tasks;
using Xunit;
using Moq;
using BankingApp.Services;
using BankingApp.Models;
using BankingApp.Repositories;

namespace BankingApp.Tests.Services
{
    public class AccountServiceTests
    {
        private readonly Mock<IAccountRepository> _accountRepositoryMock;
        private readonly AccountService _accountService;

        public AccountServiceTests()
        {
            _accountRepositoryMock = new Mock<IAccountRepository>();
            _accountService = new AccountService(_accountRepositoryMock.Object);
        }

        [Fact]
        public async Task TestCreateAccount()
        {
            // Arrange
            var newAccount = new Account { Id = Guid.NewGuid(), Name = "Test Account", Balance = 1000 };
            _accountRepositoryMock.Setup(repo => repo.CreateAccountAsync(It.IsAny<Account>()))
                                  .ReturnsAsync(newAccount);

            // Act
            var result = await _accountService.CreateAccountAsync(newAccount);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(newAccount.Id, result.Id);
            Assert.Equal(newAccount.Name, result.Name);
            Assert.Equal(newAccount.Balance, result.Balance);
            _accountRepositoryMock.Verify(repo => repo.CreateAccountAsync(It.IsAny<Account>()), Times.Once);
        }

        [Fact]
        public async Task TestGetAccountById()
        {
            // Arrange
            var accountId = Guid.NewGuid();
            var account = new Account { Id = accountId, Name = "Existing Account", Balance = 500 };
            _accountRepositoryMock.Setup(repo => repo.GetAccountByIdAsync(accountId))
                                  .ReturnsAsync(account);

            // Act
            var result = await _accountService.GetAccountByIdAsync(accountId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(accountId, result.Id);
            Assert.Equal(account.Name, result.Name);
            Assert.Equal(account.Balance, result.Balance);
            _accountRepositoryMock.Verify(repo => repo.GetAccountByIdAsync(accountId), Times.Once);
        }

        [Fact]
        public async Task TestUpdateAccount()
        {
            // Arrange
            var accountId = Guid.NewGuid();
            var updatedAccount = new Account { Id = accountId, Name = "Updated Account", Balance = 1500 };
            _accountRepositoryMock.Setup(repo => repo.UpdateAccountAsync(It.IsAny<Account>()))
                                  .ReturnsAsync(updatedAccount);

            // Act
            var result = await _accountService.UpdateAccountAsync(updatedAccount);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(updatedAccount.Id, result.Id);
            Assert.Equal(updatedAccount.Name, result.Name);
            Assert.Equal(updatedAccount.Balance, result.Balance);
            _accountRepositoryMock.Verify(repo => repo.UpdateAccountAsync(It.IsAny<Account>()), Times.Once);
        }

        [Fact]
        public async Task TestDeleteAccount()
        {
            // Arrange
            var accountId = Guid.NewGuid();
            _accountRepositoryMock.Setup(repo => repo.DeleteAccountAsync(accountId))
                                  .Returns(Task.CompletedTask);

            // Act
            await _accountService.DeleteAccountAsync(accountId);

            // Assert
            _accountRepositoryMock.Verify(repo => repo.DeleteAccountAsync(accountId), Times.Once);
        }
    }
}
