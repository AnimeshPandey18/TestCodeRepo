using System;
using System.Threading.Tasks;
using Moq;
using Xunit;
using BankingApp.Services;
using BankingApp.Models;
using BankingApp.Repositories;

namespace BankingApp.Tests.Services
{
    public class TransactionServiceTests
    {
        private readonly Mock<ITransactionRepository> _transactionRepositoryMock;
        private readonly TransactionService _transactionService;

        public TransactionServiceTests()
        {
            _transactionRepositoryMock = new Mock<ITransactionRepository>();
            _transactionService = new TransactionService(_transactionRepositoryMock.Object);
        }

        [Fact]
        public async Task TestCreateTransaction_Success()
        {
            // Arrange
            var transaction = new Transaction { Id = Guid.NewGuid(), Amount = 100, Description = "Test Transaction" };
            _transactionRepositoryMock.Setup(repo => repo.CreateTransactionAsync(It.IsAny<Transaction>()))
                .ReturnsAsync(transaction);

            // Act
            var result = await _transactionService.CreateTransactionAsync(transaction);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(transaction.Id, result.Id);
            _transactionRepositoryMock.Verify(repo => repo.CreateTransactionAsync(It.IsAny<Transaction>()), Times.Once);
        }

        [Fact]
        public async Task TestGetTransactionById_Success()
        {
            // Arrange
            var transactionId = Guid.NewGuid();
            var transaction = new Transaction { Id = transactionId, Amount = 100, Description = "Test Transaction" };
            _transactionRepositoryMock.Setup(repo => repo.GetTransactionByIdAsync(transactionId))
                .ReturnsAsync(transaction);

            // Act
            var result = await _transactionService.GetTransactionByIdAsync(transactionId);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(transactionId, result.Id);
            _transactionRepositoryMock.Verify(repo => repo.GetTransactionByIdAsync(transactionId), Times.Once);
        }

        [Fact]
        public async Task TestUpdateTransaction_Success()
        {
            // Arrange
            var transaction = new Transaction { Id = Guid.NewGuid(), Amount = 100, Description = "Test Transaction" };
            _transactionRepositoryMock.Setup(repo => repo.UpdateTransactionAsync(It.IsAny<Transaction>()))
                .ReturnsAsync(true);

            // Act
            var result = await _transactionService.UpdateTransactionAsync(transaction);

            // Assert
            Assert.True(result);
            _transactionRepositoryMock.Verify(repo => repo.UpdateTransactionAsync(It.IsAny<Transaction>()), Times.Once);
        }

        [Fact]
        public async Task TestDeleteTransaction_Success()
        {
            // Arrange
            var transactionId = Guid.NewGuid();
            _transactionRepositoryMock.Setup(repo => repo.DeleteTransactionAsync(transactionId))
                .ReturnsAsync(true);

            // Act
            var result = await _transactionService.DeleteTransactionAsync(transactionId);

            // Assert
            Assert.True(result);
            _transactionRepositoryMock.Verify(repo => repo.DeleteTransactionAsync(transactionId), Times.Once);
        }

        [Fact]
        public async Task TestCreateTransaction_Failure()
        {
            // Arrange
            _transactionRepositoryMock.Setup(repo => repo.CreateTransactionAsync(It.IsAny<Transaction>()))
                .ThrowsAsync(new Exception("Database error"));

            // Act & Assert
            await Assert.ThrowsAsync<Exception>(() => _transactionService.CreateTransactionAsync(new Transaction()));
        }

        [Fact]
        public async Task TestGetTransactionById_NotFound()
        {
            // Arrange
            var transactionId = Guid.NewGuid();
            _transactionRepositoryMock.Setup(repo => repo.GetTransactionByIdAsync(transactionId))
                .ReturnsAsync((Transaction)null);

            // Act
            var result = await _transactionService.GetTransactionByIdAsync(transactionId);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task TestUpdateTransaction_Failure()
        {
            // Arrange
            _transactionRepositoryMock.Setup(repo => repo.UpdateTransactionAsync(It.IsAny<Transaction>()))
                .ReturnsAsync(false);

            // Act
            var result = await _transactionService.UpdateTransactionAsync(new Transaction());

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task TestDeleteTransaction_Failure()
        {
            // Arrange
            var transactionId = Guid.NewGuid();
            _transactionRepositoryMock.Setup(repo => repo.DeleteTransactionAsync(transactionId))
                .ReturnsAsync(false);

            // Act
            var result = await _transactionService.DeleteTransactionAsync(transactionId);

            // Assert
            Assert.False(result);
        }
    }
}
