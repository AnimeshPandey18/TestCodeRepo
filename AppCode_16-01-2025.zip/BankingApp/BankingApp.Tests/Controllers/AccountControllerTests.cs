using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using BankingApp.Controllers;
using Moq;
using Xunit;
using Microsoft.AspNetCore.Mvc;
using BankingApp.Models;
using BankingApp.Services;

namespace BankingApp.Tests.Controllers
{
    public class AccountControllerTests
    {
        private readonly Mock<IAccountService> _mockAccountService;
        private readonly AccountController _accountController;

        public AccountControllerTests()
        {
            _mockAccountService = new Mock<IAccountService>();
            _accountController = new AccountController(_mockAccountService.Object);
        }

        [Fact]
        public async Task TestAccountCreationEndpoint()
        {
            // Arrange
            var newAccount = new Account { Id = 1, Name = "Test Account", Balance = 1000 };
            _mockAccountService.Setup(service => service.CreateAccountAsync(It.IsAny<Account>()))
                .ReturnsAsync(newAccount);

            // Act
            var result = await _accountController.CreateAccount(newAccount);

            // Assert
            var actionResult = Assert.IsType<CreatedAtActionResult>(result);
            var returnValue = Assert.IsType<Account>(actionResult.Value);
            Assert.Equal(newAccount.Id, returnValue.Id);
        }

        [Fact]
        public async Task TestGetAccountEndpoint()
        {
            // Arrange
            var accountId = 1;
            var account = new Account { Id = accountId, Name = "Test Account", Balance = 1000 };
            _mockAccountService.Setup(service => service.GetAccountByIdAsync(accountId))
                .ReturnsAsync(account);

            // Act
            var result = await _accountController.GetAccount(accountId);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<Account>(actionResult.Value);
            Assert.Equal(accountId, returnValue.Id);
        }

        [Fact]
        public async Task TestUpdateAccountEndpoint()
        {
            // Arrange
            var accountId = 1;
            var updatedAccount = new Account { Id = accountId, Name = "Updated Account", Balance = 2000 };
            _mockAccountService.Setup(service => service.UpdateAccountAsync(accountId, It.IsAny<Account>()))
                .ReturnsAsync(updatedAccount);

            // Act
            var result = await _accountController.UpdateAccount(accountId, updatedAccount);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<Account>(actionResult.Value);
            Assert.Equal(updatedAccount.Name, returnValue.Name);
        }

        [Fact]
        public async Task TestDeleteAccountEndpoint()
        {
            // Arrange
            var accountId = 1;
            _mockAccountService.Setup(service => service.DeleteAccountAsync(accountId))
                .ReturnsAsync(true);

            // Act
            var result = await _accountController.DeleteAccount(accountId);

            // Assert
            var actionResult = Assert.IsType<OkResult>(result);
        }
    }
}
