using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Moq;
using Microsoft.AspNetCore.Mvc.Testing;
using BankingApp.Controllers;
using BankingApp.Models;
using Newtonsoft.Json;

namespace BankingApp.Tests.Controllers
{
    public class CustomerControllerTests : IClassFixture<WebApplicationFactory<BankingApp.Startup>>
    {
        private readonly HttpClient _client;
        private readonly Mock<ICustomerService> _mockCustomerService;

        public CustomerControllerTests(WebApplicationFactory<BankingApp.Startup> factory)
        {
            _client = factory.CreateClient();
            _mockCustomerService = new Mock<ICustomerService>();
        }

        [Fact]
        public async Task TestCustomerCreationEndpoint()
        {
            // Arrange
            var newCustomer = new Customer { Name = "John Doe", Email = "john.doe@example.com" };
            var jsonContent = new StringContent(JsonConvert.SerializeObject(newCustomer), Encoding.UTF8, "application/json");

            _mockCustomerService.Setup(service => service.CreateCustomerAsync(It.IsAny<Customer>()))
                .ReturnsAsync(newCustomer);

            // Act
            var response = await _client.PostAsync("/api/customers", jsonContent);

            // Assert
            Assert.Equal(HttpStatusCode.Created, response.StatusCode);
            var responseString = await response.Content.ReadAsStringAsync();
            var createdCustomer = JsonConvert.DeserializeObject<Customer>(responseString);
            Assert.Equal(newCustomer.Name, createdCustomer.Name);
            Assert.Equal(newCustomer.Email, createdCustomer.Email);
        }

        [Fact]
        public async Task TestGetCustomerEndpoint()
        {
            // Arrange
            var customerId = 1;
            var expectedCustomer = new Customer { Id = customerId, Name = "John Doe", Email = "john.doe@example.com" };

            _mockCustomerService.Setup(service => service.GetCustomerByIdAsync(customerId))
                .ReturnsAsync(expectedCustomer);

            // Act
            var response = await _client.GetAsync($"/api/customers/{customerId}");

            // Assert
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var responseString = await response.Content.ReadAsStringAsync();
            var customer = JsonConvert.DeserializeObject<Customer>(responseString);
            Assert.Equal(expectedCustomer.Name, customer.Name);
            Assert.Equal(expectedCustomer.Email, customer.Email);
        }

        [Fact]
        public async Task TestUpdateCustomerEndpoint()
        {
            // Arrange
            var customerId = 1;
            var updatedCustomer = new Customer { Id = customerId, Name = "Jane Doe", Email = "jane.doe@example.com" };
            var jsonContent = new StringContent(JsonConvert.SerializeObject(updatedCustomer), Encoding.UTF8, "application/json");

            _mockCustomerService.Setup(service => service.UpdateCustomerAsync(It.IsAny<Customer>()))
                .ReturnsAsync(updatedCustomer);

            // Act
            var response = await _client.PutAsync($"/api/customers/{customerId}", jsonContent);

            // Assert
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var responseString = await response.Content.ReadAsStringAsync();
            var customer = JsonConvert.DeserializeObject<Customer>(responseString);
            Assert.Equal(updatedCustomer.Name, customer.Name);
            Assert.Equal(updatedCustomer.Email, customer.Email);
        }

        [Fact]
        public async Task TestDeleteCustomerEndpoint()
        {
            // Arrange
            var customerId = 1;

            _mockCustomerService.Setup(service => service.DeleteCustomerAsync(customerId))
                .ReturnsAsync(true);

            // Act
            var response = await _client.DeleteAsync($"/api/customers/{customerId}");

            // Assert
            Assert.Equal(HttpStatusCode.NoContent, response.StatusCode);
        }
    }
}
