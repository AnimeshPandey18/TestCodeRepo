using System;
using System.Net.Http;
using System.Threading.Tasks;
using BankingApp.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace BankingApp.Tests.Controllers
{
    public class TransactionControllerTests
    {
        private readonly Mock<IHttpClientFactory> _httpClientFactoryMock;
        private readonly TransactionController _controller;

        public TransactionControllerTests()
        {
            _httpClientFactoryMock = new Mock<IHttpClientFactory>();
            _controller = new TransactionController(_httpClientFactoryMock.Object);
        }

        [Fact]
        public async Task TestTransactionCreationEndpoint()
        {
            // Arrange
            var httpClientMock = new Mock<HttpClient>();
            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(httpClientMock.Object);

            // Act
            var result = await _controller.CreateTransaction(new TransactionModel { /* Initialize with test data */ });

            // Assert
            var actionResult = Assert.IsType<ActionResult<TransactionResponse>>(result);
            var createdResult = Assert.IsType<CreatedAtActionResult>(actionResult.Result);
            Assert.NotNull(createdResult.Value);
        }

        [Fact]
        public async Task TestGetTransactionEndpoint()
        {
            // Arrange
            var httpClientMock = new Mock<HttpClient>();
            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(httpClientMock.Object);

            // Act
            var result = await _controller.GetTransaction(1); // Assuming 1 is a valid transaction ID for testing

            // Assert
            var actionResult = Assert.IsType<ActionResult<TransactionResponse>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            Assert.NotNull(okResult.Value);
        }

        [Fact]
        public async Task TestUpdateTransactionEndpoint()
        {
            // Arrange
            var httpClientMock = new Mock<HttpClient>();
            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(httpClientMock.Object);

            // Act
            var result = await _controller.UpdateTransaction(1, new TransactionModel { /* Initialize with test data */ });

            // Assert
            var actionResult = Assert.IsType<ActionResult<TransactionResponse>>(result);
            var okResult = Assert.IsType<OkObjectResult>(actionResult.Result);
            Assert.NotNull(okResult.Value);
        }

        [Fact]
        public async Task TestDeleteTransactionEndpoint()
        {
            // Arrange
            var httpClientMock = new Mock<HttpClient>();
            _httpClientFactoryMock.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(httpClientMock.Object);

            // Act
            var result = await _controller.DeleteTransaction(1); // Assuming 1 is a valid transaction ID for testing

            // Assert
            var actionResult = Assert.IsType<ActionResult>(result);
            Assert.IsType<NoContentResult>(actionResult);
        }
    }
}
