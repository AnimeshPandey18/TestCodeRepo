using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BankingApp.Data
{
    // Define a generic repository interface for CRUD operations
    public interface IRepository<T>
    {
        Task<IEnumerable<T>> GetAllAsync();
        Task<T> GetByIdAsync(Guid id);
        Task CreateAsync(T entity);
        Task UpdateAsync(T entity);
        Task DeleteAsync(Guid id);
    }

    // Define specific repository interfaces for each entity
    public interface IBankingAPIRepository : IRepository<BankingAPI>
    {
        Task<BankingAPI> GetByNameAsync(string apiName);
    }

    public interface IEndpointRepository : IRepository<Endpoint>
    {
        Task<IEnumerable<Endpoint>> GetByApiIdAsync(Guid apiId);
    }

    public interface IParameterRepository : IRepository<Parameter>
    {
        Task<IEnumerable<Parameter>> GetByEndpointIdAsync(Guid endpointId);
    }

    public interface IResponseRepository : IRepository<Response>
    {
        Task<IEnumerable<Response>> GetByEndpointIdAsync(Guid endpointId);
    }

    public interface IAuthenticationRepository : IRepository<Authentication>
    {
        Task<Authentication> GetByApiIdAsync(Guid apiId);
    }

    public interface IUserRepository : IRepository<User>
    {
        Task<User> GetByUsernameAsync(string username);
    }

    public interface ILogRepository : IRepository<Log>
    {
        Task<IEnumerable<Log>> GetByUserIdAsync(Guid userId);
    }
}

// Entity classes representing the database schema
public class BankingAPI
{
    public Guid API_ID { get; set; }
    public string API_Name { get; set; }
    public string Description { get; set; }
    public string Version { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime ModifiedDate { get; set; }
}

public class Endpoint
{
    public Guid Endpoint_ID { get; set; }
    public Guid API_ID { get; set; }
    public string Endpoint_Name { get; set; }
    public string URL { get; set; }
    public string Method { get; set; }
    public string Description { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime ModifiedDate { get; set; }
}

public class Parameter
{
    public Guid Parameter_ID { get; set; }
    public Guid Endpoint_ID { get; set; }
    public string Name { get; set; }
    public string Type { get; set; }
    public bool IsRequired { get; set; }
    public string DefaultValue { get; set; }
    public string Description { get; set; }
}

public class Response
{
    public Guid Response_ID { get; set; }
    public Guid Endpoint_ID { get; set; }
    public int StatusCode { get; set; }
    public string Description { get; set; }
    public string Schema { get; set; }
}

public class Authentication
{
    public Guid Auth_ID { get; set; }
    public Guid API_ID { get; set; }
    public string Auth_Type { get; set; }
    public string Details { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime ModifiedDate { get; set; }
}

public class User
{
    public Guid User_ID { get; set; }
    public string Username { get; set; }
    public string PasswordHash { get; set; }
    public string Email { get; set; }
    public string Role { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime ModifiedDate { get; set; }
}

public class Log
{
    public Guid Log_ID { get; set; }
    public Guid API_ID { get; set; }
    public Guid User_ID { get; set; }
    public string Action { get; set; }
    public DateTime Timestamp { get; set; }
    public string Status { get; set; }
    public string Message { get; set; }
}
