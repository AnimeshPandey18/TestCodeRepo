using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Threading.Tasks;
using BankingApp.Models;

namespace BankingApp.Data
{
    public class BankingContext : DbContext
    {
        private readonly HttpClient _httpClient;
        private readonly string _udmsHost;
        private readonly TimeSpan _udmsTimeout;

        public DbSet<Account> Accounts { get; set; }
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<Customer> Customers { get; set; }

        public BankingContext(DbContextOptions<BankingContext> options, IConfiguration configuration) : base(options)
        {
            _httpClient = new HttpClient();
            _udmsHost = configuration["UDMS_HOST"];
            _udmsTimeout = TimeSpan.FromSeconds(Convert.ToDouble(configuration["UDMS_Timeout"]));
            _httpClient.Timeout = _udmsTimeout;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure entity relationships and mappings
            modelBuilder.Entity<Account>().ToTable("Accounts");
            modelBuilder.Entity<Transaction>().ToTable("Transactions");
            modelBuilder.Entity<Customer>().ToTable("Customers");

            // Additional configurations can be added here
        }

        public async Task<T> GetDataFromUdmsAsync<T>(string endpoint)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_udmsHost}/{endpoint}");
                response.EnsureSuccessStatusCode();
                var data = await response.Content.ReadAsAsync<T>();
                return data;
            }
            catch (HttpRequestException e)
            {
                // Log exception details
                Console.WriteLine($"Request error: {e.Message}");
                throw;
            }
            catch (Exception e)
            {
                // Log exception details
                Console.WriteLine($"Unexpected error: {e.Message}");
                throw;
            }
        }

        public async Task PostDataToUdmsAsync<T>(string endpoint, T data)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync($"{_udmsHost}/{endpoint}", data);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException e)
            {
                // Log exception details
                Console.WriteLine($"Request error: {e.Message}");
                throw;
            }
            catch (Exception e)
            {
                // Log exception details
                Console.WriteLine($"Unexpected error: {e.Message}");
                throw;
            }
        }

        public async Task UpdateDataInUdmsAsync<T>(string endpoint, T data)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync($"{_udmsHost}/{endpoint}", data);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException e)
            {
                // Log exception details
                Console.WriteLine($"Request error: {e.Message}");
                throw;
            }
            catch (Exception e)
            {
                // Log exception details
                Console.WriteLine($"Unexpected error: {e.Message}");
                throw;
            }
        }
    }
}
