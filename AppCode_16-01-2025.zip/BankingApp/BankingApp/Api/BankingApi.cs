using System;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace BankingApp.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class BankingApi : ControllerBase
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<BankingApi> _logger;
        private readonly string _udmsHost;
        private readonly TimeSpan _udmsTimeout;

        public BankingApi(IConfiguration configuration, ILogger<BankingApi> logger)
        {
            _httpClient = new HttpClient();
            _logger = logger;
            _udmsHost = configuration["UDMS_HOST"];
            _udmsTimeout = TimeSpan.FromSeconds(int.Parse(configuration["UDMS_Timeout"]));
            _httpClient.Timeout = _udmsTimeout;
        }

        [HttpGet("accounts")]
        public async Task<IActionResult> GetAccounts()
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_udmsHost}/accounts");
                response.EnsureSuccessStatusCode();
                var accountsData = await response.Content.ReadAsStringAsync();
                return Ok(accountsData);
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Error fetching accounts from UDMS.");
                return StatusCode(500, "Internal server error while fetching accounts.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error occurred.");
                return StatusCode(500, "An unexpected error occurred.");
            }
        }

        [HttpPost("transactions")]
        public async Task<IActionResult> CreateTransaction([FromBody] TransactionRequest transactionRequest)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync($"{_udmsHost}/transactions", transactionRequest);
                response.EnsureSuccessStatusCode();
                var transactionData = await response.Content.ReadAsStringAsync();
                return Ok(transactionData);
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Error creating transaction in UDMS.");
                return StatusCode(500, "Internal server error while creating transaction.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error occurred.");
                return StatusCode(500, "An unexpected error occurred.");
            }
        }

        [HttpGet("customers")]
        public async Task<IActionResult> GetCustomers()
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_udmsHost}/customers");
                response.EnsureSuccessStatusCode();
                var customersData = await response.Content.ReadAsStringAsync();
                return Ok(customersData);
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Error fetching customers from UDMS.");
                return StatusCode(500, "Internal server error while fetching customers.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error occurred.");
                return StatusCode(500, "An unexpected error occurred.");
            }
        }
    }

    public class TransactionRequest
    {
        public string AccountId { get; set; }
        public decimal Amount { get; set; }
        public string Description { get; set; }
    }
}
