using System;
using System.Globalization;

namespace BankingApp.Utilities
{
    public static class Extensions
    {
        /// <summary>
        /// Converts a string to title case.
        /// </summary>
        /// <param name="input">The input string.</param>
        /// <returns>The title-cased string.</returns>
        public static string ToTitleCase(this string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                throw new ArgumentException("Input cannot be null or whitespace.", nameof(input));
            }

            TextInfo textInfo = CultureInfo.CurrentCulture.TextInfo;
            return textInfo.ToTitleCase(input.ToLower());
        }

        /// <summary>
        /// Formats a DateTime object to a specific string format.
        /// </summary>
        /// <param name="dateTime">The DateTime object.</param>
        /// <param name="format">The desired format string.</param>
        /// <returns>The formatted date string.</returns>
        public static string ToFormattedString(this DateTime dateTime, string format)
        {
            if (string.IsNullOrWhiteSpace(format))
            {
                throw new ArgumentException("Format cannot be null or whitespace.", nameof(format));
            }

            try
            {
                return dateTime.ToString(format, CultureInfo.InvariantCulture);
            }
            catch (FormatException ex)
            {
                throw new ArgumentException("Invalid format string.", ex);
            }
        }

        /// <summary>
        /// Safely parses a string to an integer, returning a default value if parsing fails.
        /// </summary>
        /// <param name="input">The input string.</param>
        /// <param name="defaultValue">The default value to return if parsing fails.</param>
        /// <returns>The parsed integer or the default value.</returns>
        public static int SafeParseInt(this string input, int defaultValue = 0)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return defaultValue;
            }

            return int.TryParse(input, out int result) ? result : defaultValue;
        }

        /// <summary>
        /// Checks if a string is a valid email format.
        /// </summary>
        /// <param name="email">The email string.</param>
        /// <returns>True if valid, otherwise false.</returns>
        public static bool IsValidEmail(this string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return false;
            }

            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
    }
}
