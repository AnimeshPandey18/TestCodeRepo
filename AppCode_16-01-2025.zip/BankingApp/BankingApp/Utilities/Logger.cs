using System;
using System.IO;
using System.Text.Json;

namespace BankingApp.Utilities
{
    public static class Logger
    {
        private static readonly string logFilePath = "logs/log.txt";

        static Logger()
        {
            // Ensure the log directory exists
            Directory.CreateDirectory(Path.GetDirectoryName(logFilePath));
        }

        /// <summary>
        /// Logs an action performed by the API or user.
        /// </summary>
        /// <param name="apiId">The ID of the API being logged.</param>
        /// <param name="userId">The ID of the user performing the action.</param>
        /// <param name="action">The action being performed.</param>
        /// <param name="status">The status of the action.</param>
        /// <param name="message">Additional message or information about the action.</param>
        public static void LogAction(string apiId, string userId, string action, string status, string message)
        {
            try
            {
                var logEntry = new LogEntry
                {
                    LogId = Guid.NewGuid().ToString(),
                    ApiId = apiId,
                    UserId = userId,
                    Action = action,
                    Timestamp = DateTime.UtcNow,
                    Status = status,
                    Message = message
                };

                string logContent = JsonSerializer.Serialize(logEntry);
                File.AppendAllText(logFilePath, logContent + Environment.NewLine);
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Failed to log action: {ex.Message}");
                // Consider additional error handling or alerting mechanisms
            }
        }

        private class LogEntry
        {
            public string LogId { get; set; }
            public string ApiId { get; set; }
            public string UserId { get; set; }
            public string Action { get; set; }
            public DateTime Timestamp { get; set; }
            public string Status { get; set; }
            public string Message { get; set; }
        }
    }
}
