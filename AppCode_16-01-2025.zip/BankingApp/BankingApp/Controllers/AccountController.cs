using System;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BankingApp.Services;
using BankingApp.Models;

namespace BankingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountController : ControllerBase
    {
        private readonly IAccountService _accountService;
        private static readonly HttpClient _httpClient = new HttpClient
        {
            BaseAddress = new Uri("UDMS_HOST"),
            Timeout = TimeSpan.FromSeconds(UDMS_Timeout)
        };

        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;
        }

        [HttpPost]
        [Route("accounts")]
        public async Task<IActionResult> CreateAccount([FromBody] Account account)
        {
            try
            {
                var response = await _accountService.CreateAccountAsync(account);
                if (response.IsSuccessStatusCode)
                {
                    return Ok(await response.Content.ReadAsAsync<Account>());
                }
                return StatusCode((int)response.StatusCode, response.ReasonPhrase);
            }
            catch (Exception ex)
            {
                // Log exception
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("accounts/{accountId}")]
        public async Task<IActionResult> GetAccountById(int accountId)
        {
            try
            {
                var response = await _accountService.GetAccountByIdAsync(accountId);
                if (response.IsSuccessStatusCode)
                {
                    return Ok(await response.Content.ReadAsAsync<Account>());
                }
                return StatusCode((int)response.StatusCode, response.ReasonPhrase);
            }
            catch (Exception ex)
            {
                // Log exception
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut]
        [Route("accounts/{accountId}")]
        public async Task<IActionResult> UpdateAccount(int accountId, [FromBody] Account account)
        {
            try
            {
                var response = await _accountService.UpdateAccountAsync(accountId, account);
                if (response.IsSuccessStatusCode)
                {
                    return Ok(await response.Content.ReadAsAsync<Account>());
                }
                return StatusCode((int)response.StatusCode, response.ReasonPhrase);
            }
            catch (Exception ex)
            {
                // Log exception
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete]
        [Route("accounts/{accountId}")]
        public async Task<IActionResult> DeleteAccount(int accountId)
        {
            try
            {
                var response = await _accountService.DeleteAccountAsync(accountId);
                if (response.IsSuccessStatusCode)
                {
                    return NoContent();
                }
                return StatusCode((int)response.StatusCode, response.ReasonPhrase);
            }
            catch (Exception ex)
            {
                // Log exception
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
