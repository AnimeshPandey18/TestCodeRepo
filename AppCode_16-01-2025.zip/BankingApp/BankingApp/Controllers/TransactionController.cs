using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BankingApp.Services;
using BankingApp.Models;

namespace BankingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionService _transactionService;
        private static readonly HttpClient _httpClient = new HttpClient
        {
            Timeout = TimeSpan.FromSeconds(30) // UDMS_Timeout
        };

        private const string UDMS_HOST = "https://udms.example.com"; // Base URL for UDMS

        public TransactionController(ITransactionService transactionService)
        {
            _transactionService = transactionService;
        }

        [HttpPost]
        public async Task<IActionResult> CreateTransaction([FromBody] Transaction transaction)
        {
            try
            {
                if (transaction == null)
                {
                    return BadRequest("Transaction data is required.");
                }

                var response = await _httpClient.PostAsJsonAsync($"{UDMS_HOST}/transactions", transaction);
                response.EnsureSuccessStatusCode();

                var createdTransaction = await response.Content.ReadAsAsync<Transaction>();
                return CreatedAtAction(nameof(GetTransactionById), new { transactionId = createdTransaction.Id }, createdTransaction);
            }
            catch (HttpRequestException ex)
            {
                return StatusCode(503, $"Error communicating with UDMS: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{transactionId}")]
        public async Task<IActionResult> GetTransactionById(int transactionId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{UDMS_HOST}/transactions/{transactionId}");
                if (!response.IsSuccessStatusCode)
                {
                    return NotFound($"Transaction with ID {transactionId} not found.");
                }

                var transaction = await response.Content.ReadAsAsync<Transaction>();
                return Ok(transaction);
            }
            catch (HttpRequestException ex)
            {
                return StatusCode(503, $"Error communicating with UDMS: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{transactionId}")]
        public async Task<IActionResult> UpdateTransaction(int transactionId, [FromBody] Transaction transaction)
        {
            try
            {
                if (transaction == null)
                {
                    return BadRequest("Transaction data is required.");
                }

                var response = await _httpClient.PutAsJsonAsync($"{UDMS_HOST}/transactions/{transactionId}", transaction);
                if (!response.IsSuccessStatusCode)
                {
                    return NotFound($"Transaction with ID {transactionId} not found.");
                }

                return NoContent();
            }
            catch (HttpRequestException ex)
            {
                return StatusCode(503, $"Error communicating with UDMS: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("{transactionId}")]
        public async Task<IActionResult> DeleteTransaction(int transactionId)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"{UDMS_HOST}/transactions/{transactionId}");
                if (!response.IsSuccessStatusCode)
                {
                    return NotFound($"Transaction with ID {transactionId} not found.");
                }

                return NoContent();
            }
            catch (HttpRequestException ex)
            {
                return StatusCode(503, $"Error communicating with UDMS: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
