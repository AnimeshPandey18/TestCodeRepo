using System;
using System.ComponentModel.DataAnnotations;

namespace BankingApp.Models
{
    /// <summary>
    /// Represents a transaction within the banking application.
    /// </summary>
    public class Transaction
    {
        /// <summary>
        /// Gets or sets the unique identifier for the transaction.
        /// </summary>
        [Key]
        public Guid TransactionId { get; set; }

        /// <summary>
        /// Gets or sets the amount involved in the transaction.
        /// </summary>
        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Amount must be greater than zero.")]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets the date and time when the transaction was created.
        /// </summary>
        [Required]
        public DateTime CreatedDate { get; set; }

        /// <summary>
        /// Gets or sets the type of the transaction (e.g., Credit, Debit).
        /// </summary>
        [Required]
        [StringLength(50)]
        public string TransactionType { get; set; }

        /// <summary>
        /// Gets or sets the description of the transaction.
        /// </summary>
        [StringLength(255)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the status of the transaction (e.g., Pending, Completed).
        /// </summary>
        [Required]
        [StringLength(50)]
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the user identifier associated with the transaction.
        /// </summary>
        [Required]
        public Guid UserId { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Transaction"/> class.
        /// </summary>
        public Transaction()
        {
            TransactionId = Guid.NewGuid();
            CreatedDate = DateTime.UtcNow;
        }
    }
}
