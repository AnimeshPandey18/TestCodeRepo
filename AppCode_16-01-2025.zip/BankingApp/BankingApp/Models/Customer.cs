using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace BankingApp.Models
{
    public class Customer
    {
        // Properties representing the Customer entity
        public int CustomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }

        // Base URL for the Unified Data Management System (UDMS)
        private static readonly string UDMS_HOST = "https://udms.example.com/api";
        private static readonly TimeSpan UDMS_Timeout = TimeSpan.FromSeconds(30);

        // HttpClient instance for making requests to UDMS
        private static readonly HttpClient httpClient = new HttpClient
        {
            Timeout = UDMS_Timeout
        };

        // Method to retrieve customer data from UDMS
        public static async Task<Customer> GetCustomerByIdAsync(int customerId)
        {
            try
            {
                var response = await httpClient.GetAsync($"{UDMS_HOST}/customers/{customerId}");
                response.EnsureSuccessStatusCode();

                var jsonResponse = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Customer>(jsonResponse);
            }
            catch (HttpRequestException e)
            {
                // Handle HTTP request exceptions
                Console.WriteLine($"Request error: {e.Message}");
                throw;
            }
            catch (Exception e)
            {
                // Handle other exceptions
                Console.WriteLine($"Unexpected error: {e.Message}");
                throw;
            }
        }

        // Method to update customer data in UDMS
        public static async Task<bool> UpdateCustomerAsync(Customer customer)
        {
            try
            {
                var jsonContent = JsonConvert.SerializeObject(customer);
                var content = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");

                var response = await httpClient.PutAsync($"{UDMS_HOST}/customers/{customer.CustomerId}", content);
                response.EnsureSuccessStatusCode();

                return response.IsSuccessStatusCode;
            }
            catch (HttpRequestException e)
            {
                // Handle HTTP request exceptions
                Console.WriteLine($"Request error: {e.Message}");
                throw;
            }
            catch (Exception e)
            {
                // Handle other exceptions
                Console.WriteLine($"Unexpected error: {e.Message}");
                throw;
            }
        }

        // Method to create a new customer in UDMS
        public static async Task<Customer> CreateCustomerAsync(Customer customer)
        {
            try
            {
                var jsonContent = JsonConvert.SerializeObject(customer);
                var content = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");

                var response = await httpClient.PostAsync($"{UDMS_HOST}/customers", content);
                response.EnsureSuccessStatusCode();

                var jsonResponse = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Customer>(jsonResponse);
            }
            catch (HttpRequestException e)
            {
                // Handle HTTP request exceptions
                Console.WriteLine($"Request error: {e.Message}");
                throw;
            }
            catch (Exception e)
            {
                // Handle other exceptions
                Console.WriteLine($"Unexpected error: {e.Message}");
                throw;
            }
        }
    }
}
