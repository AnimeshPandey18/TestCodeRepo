using System;

namespace BankingApp.Models
{
    /// <summary>
    /// Represents a bank account entity with properties for account management.
    /// </summary>
    public class Account
    {
        /// <summary>
        /// Gets or sets the unique account number.
        /// </summary>
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets the balance of the account.
        /// </summary>
        public decimal Balance { get; set; }

        /// <summary>
        /// Gets or sets the type of the account (e.g., Savings, Checking).
        /// </summary>
        public string AccountType { get; set; }

        /// <summary>
        /// Gets or sets the date when the account was created.
        /// </summary>
        public DateTime CreatedDate { get; set; }

        /// <summary>
        /// Gets or sets the date when the account was last modified.
        /// </summary>
        public DateTime ModifiedDate { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Account"/> class.
        /// </summary>
        public Account()
        {
            // Initialize default values if necessary
            CreatedDate = DateTime.UtcNow;
            ModifiedDate = DateTime.UtcNow;
        }

        /// <summary>
        /// Updates the balance of the account.
        /// </summary>
        /// <param name="amount">The amount to update the balance by.</param>
        /// <exception cref="ArgumentException">Thrown when the amount is invalid.</exception>
        public void UpdateBalance(decimal amount)
        {
            if (amount == 0)
            {
                throw new ArgumentException("Amount must be non-zero.", nameof(amount));
            }

            Balance += amount;
            ModifiedDate = DateTime.UtcNow;
        }

        /// <summary>
        /// Validates the account details.
        /// </summary>
        /// <exception cref="InvalidOperationException">Thrown when account details are invalid.</exception>
        public void ValidateAccount()
        {
            if (string.IsNullOrWhiteSpace(AccountNumber))
            {
                throw new InvalidOperationException("Account number cannot be null or empty.");
            }

            if (Balance < 0)
            {
                throw new InvalidOperationException("Balance cannot be negative.");
            }

            if (string.IsNullOrWhiteSpace(AccountType))
            {
                throw new InvalidOperationException("Account type cannot be null or empty.");
            }
        }
    }
}
