using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using BankingApp.Models;
using BankingApp.Data;

namespace BankingApp.Services
{
    public class AccountService : IAccountService
    {
        private readonly IRepository<Account> _accountRepository;
        private static readonly HttpClient _httpClient = new HttpClient
        {
            Timeout = TimeSpan.FromSeconds(30) // Assuming UDMS_Timeout is 30 seconds
        };

        private const string UDMS_HOST = "https://udms.example.com"; // Replace with actual UDMS host

        public AccountService(IRepository<Account> accountRepository)
        {
            _accountRepository = accountRepository;
        }

        public async Task<Account> CreateAccount(Account account)
        {
            try
            {
                var response = await _httpClient.PostAsync($"{UDMS_HOST}/accounts", new StringContent(JsonConvert.SerializeObject(account), Encoding.UTF8, "application/json"));
                response.EnsureSuccessStatusCode();
                var responseData = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Account>(responseData);
            }
            catch (HttpRequestException e)
            {
                // Log exception details
                throw new Exception("Error creating account", e);
            }
        }

        public async Task<Account> GetAccountById(int accountId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{UDMS_HOST}/accounts/{accountId}");
                response.EnsureSuccessStatusCode();
                var responseData = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Account>(responseData);
            }
            catch (HttpRequestException e)
            {
                // Log exception details
                throw new Exception("Error retrieving account", e);
            }
        }

        public async Task<Account> UpdateAccount(int accountId, Account account)
        {
            try
            {
                var response = await _httpClient.PutAsync($"{UDMS_HOST}/accounts/{accountId}", new StringContent(JsonConvert.SerializeObject(account), Encoding.UTF8, "application/json"));
                response.EnsureSuccessStatusCode();
                var responseData = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Account>(responseData);
            }
            catch (HttpRequestException e)
            {
                // Log exception details
                throw new Exception("Error updating account", e);
            }
        }

        public async Task<bool> DeleteAccount(int accountId)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"{UDMS_HOST}/accounts/{accountId}");
                response.EnsureSuccessStatusCode();
                return true;
            }
            catch (HttpRequestException e)
            {
                // Log exception details
                throw new Exception("Error deleting account", e);
            }
        }
    }
}
