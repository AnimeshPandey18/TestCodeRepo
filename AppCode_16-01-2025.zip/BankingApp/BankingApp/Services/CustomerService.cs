using System;
using System.Net.Http;
using System.Threading.Tasks;
using BankingApp.Models;
using BankingApp.Data;

namespace BankingApp.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly IRepository<Customer> _customerRepository;
        private static readonly HttpClient _httpClient = new HttpClient
        {
            BaseAddress = new Uri("UDMS_HOST"),
            Timeout = TimeSpan.FromSeconds(UDMS_Timeout)
        };

        public CustomerService(IRepository<Customer> customerRepository)
        {
            _customerRepository = customerRepository;
        }

        public async Task<Customer> GetCustomerById(int customerId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"/customers/{customerId}");
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsAsync<Customer>();
            }
            catch (HttpRequestException e)
            {
                // Log exception
                throw new Exception("Error retrieving customer data", e);
            }
        }

        public async Task CreateCustomer(Customer customer)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("/customers", customer);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException e)
            {
                // Log exception
                throw new Exception("Error creating customer", e);
            }
        }

        public async Task UpdateCustomer(int customerId, Customer customer)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync($"/customers/{customerId}", customer);
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException e)
            {
                // Log exception
                throw new Exception("Error updating customer", e);
            }
        }

        public async Task DeleteCustomer(int customerId)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"/customers/{customerId}");
                response.EnsureSuccessStatusCode();
            }
            catch (HttpRequestException e)
            {
                // Log exception
                throw new Exception("Error deleting customer", e);
            }
        }
    }
}
