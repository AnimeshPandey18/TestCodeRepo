using System;
using System.Threading.Tasks;

namespace BankingApp.Services
{
    // Define the interface for transaction-related business logic services
    public interface ITransactionService
    {
        /// <summary>
        /// Handles the logic for creating a new transaction.
        /// </summary>
        /// <param name="transaction">The transaction object containing transaction details.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task CreateTransaction(Transaction transaction);

        /// <summary>
        /// Retrieves transaction details by transaction ID.
        /// </summary>
        /// <param name="transactionId">The ID of the transaction to retrieve.</param>
        /// <returns>A task representing the asynchronous operation, with the transaction details as the result.</returns>
        Task<Transaction> GetTransactionById(int transactionId);

        /// <summary>
        /// Updates transaction details for a given transaction ID.
        /// </summary>
        /// <param name="transactionId">The ID of the transaction to update.</param>
        /// <param name="transaction">The transaction object containing updated transaction details.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task UpdateTransaction(int transactionId, Transaction transaction);

        /// <summary>
        /// Deletes a transaction by transaction ID.
        /// </summary>
        /// <param name="transactionId">The ID of the transaction to delete.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task DeleteTransaction(int transactionId);
    }

    // Assuming a Transaction class exists with necessary properties
    public class Transaction
    {
        public int TransactionId { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
        public string Description { get; set; }
        // Additional properties as needed
    }
}
