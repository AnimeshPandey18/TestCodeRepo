using System.Threading.Tasks;

namespace BankingApp.Services
{
    /// <summary>
    /// Interface for customer-related operations.
    /// </summary>
    public interface ICustomerService
    {
        /// <summary>
        /// Retrieves customer details by customer ID.
        /// </summary>
        /// <param name="customerId">The ID of the customer to retrieve.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the customer details.</returns>
        Task<Customer> GetCustomerByIdAsync(int customerId);

        /// <summary>
        /// Creates a new customer.
        /// </summary>
        /// <param name="customer">The customer object containing details of the customer to create.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the created customer details.</returns>
        Task<Customer> CreateCustomerAsync(Customer customer);

        /// <summary>
        /// Updates customer details for a given customer ID.
        /// </summary>
        /// <param name="customerId">The ID of the customer to update.</param>
        /// <param name="customer">The customer object containing updated details of the customer.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the updated customer details.</returns>
        Task<Customer> UpdateCustomerAsync(int customerId, Customer customer);

        /// <summary>
        /// Deletes a customer by customer ID.
        /// </summary>
        /// <param name="customerId">The ID of the customer to delete.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        Task DeleteCustomerAsync(int customerId);
    }
}
