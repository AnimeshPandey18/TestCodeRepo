using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using BankingApp.Models;
using BankingApp.Services;
using Newtonsoft.Json;

namespace BankingApp.Services
{
    public class TransactionService : ITransactionService
    {
        private static readonly HttpClient httpClient = new HttpClient
        {
            BaseAddress = new Uri(Environment.GetEnvironmentVariable("UDMS_HOST")),
            Timeout = TimeSpan.FromSeconds(Convert.ToInt32(Environment.GetEnvironmentVariable("UDMS_Timeout")))
        };

        public async Task<Transaction> CreateTransaction(Transaction transaction)
        {
            try
            {
                var jsonContent = JsonConvert.SerializeObject(transaction);
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await httpClient.PostAsync("/transactions", content);
                response.EnsureSuccessStatusCode();

                var responseData = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Transaction>(responseData);
            }
            catch (HttpRequestException e)
            {
                // Log exception details
                Console.WriteLine($"Request error: {e.Message}");
                throw new Exception("Error creating transaction.");
            }
        }

        public async Task<Transaction> GetTransactionById(int transactionId)
        {
            try
            {
                var response = await httpClient.GetAsync($"/transactions/{transactionId}");
                response.EnsureSuccessStatusCode();

                var responseData = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Transaction>(responseData);
            }
            catch (HttpRequestException e)
            {
                // Log exception details
                Console.WriteLine($"Request error: {e.Message}");
                throw new Exception("Error retrieving transaction.");
            }
        }

        public async Task<Transaction> UpdateTransaction(int transactionId, Transaction transaction)
        {
            try
            {
                var jsonContent = JsonConvert.SerializeObject(transaction);
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await httpClient.PutAsync($"/transactions/{transactionId}", content);
                response.EnsureSuccessStatusCode();

                var responseData = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Transaction>(responseData);
            }
            catch (HttpRequestException e)
            {
                // Log exception details
                Console.WriteLine($"Request error: {e.Message}");
                throw new Exception("Error updating transaction.");
            }
        }

        public async Task<bool> DeleteTransaction(int transactionId)
        {
            try
            {
                var response = await httpClient.DeleteAsync($"/transactions/{transactionId}");
                response.EnsureSuccessStatusCode();

                return response.IsSuccessStatusCode;
            }
            catch (HttpRequestException e)
            {
                // Log exception details
                Console.WriteLine($"Request error: {e.Message}");
                throw new Exception("Error deleting transaction.");
            }
        }
    }
}
