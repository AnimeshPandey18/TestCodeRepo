using System.Threading.Tasks;

namespace BankingApp.Services
{
    // Interface for account-related operations
    public interface IAccountService
    {
        /// <summary>
        /// Creates a new account.
        /// </summary>
        /// <param name="account">The account object containing account details.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task CreateAccount(Account account);

        /// <summary>
        /// Retrieves account details by account ID.
        /// </summary>
        /// <param name="accountId">The ID of the account to retrieve.</param>
        /// <returns>A task representing the asynchronous operation, with the account details as the result.</returns>
        Task<Account> GetAccountById(int accountId);

        /// <summary>
        /// Updates account details for a given account ID.
        /// </summary>
        /// <param name="accountId">The ID of the account to update.</param>
        /// <param name="account">The account object containing updated account details.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task UpdateAccount(int accountId, Account account);

        /// <summary>
        /// Deletes an account by account ID.
        /// </summary>
        /// <param name="accountId">The ID of the account to delete.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task DeleteAccount(int accountId);
    }
}
